# QAMARIS intermittent insect audio update

## Behaviour
- No continuous ambience or looping insect bed.
- Each insect call is a 3.5-second pre-faded WAV clip, followed by 4.5 seconds of silence.
- 09:00-16:00 local time: Cicada.
- 16:00-19:00 local time: Higurashi.
- 19:00-05:00 local time: Suzumushi (reduced level from 22:00-05:00).
- 05:00-09:00 local time: silence; no fourth recording is used.
- Audio runs only while MainActivity is foreground. onPause stops ambience and UI streams.
- SunMoonWidget remains independent and silent.

## UI effects
- Pixel button tap uses ui_button_tap_pixel.
- Slider drag uses low/mid/high ticks at progress intervals with 65 ms throttling.
- Slider release uses ui_slider_release_confirm.
- SoundPool load-completion is tracked so early taps/drags are retried rather than silently lost.

## Source audio
Only the three user-attached insect recordings were converted to compact mono PCM WAV resources:
- insect_suzumushi.wav
- insect_cicada.wav
- insect_higurashi.wav

The previous five continuous ambience resources were removed. Existing five UI WAV effects were retained.

## Verification
- ZIP integrity and resource-reference consistency checked.
- All three insect WAVs checked: 22,050 Hz, mono, 16-bit PCM, 3.5 seconds.
- No audio APIs or AppAudio references in SunMoonWidget.kt; widget source hash unchanged.
- Android compilation and APK generation were not run: this workspace has no Gradle executable, Gradle wrapper, or Kotlin compiler/Android SDK.
