package com.sunmoon.karachi

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.Calendar
import kotlin.math.abs

/**
 * All audio belongs to MainActivity and is active only while that Activity is foreground.
 * No widget, receiver, worker or service references this class.
 *
 * Insect ambience is intentionally intermittent: a 3.5 second call, followed by
 * 4.5 seconds of silence. The source recordings are short, pre-faded WAV snippets.
 */
class AppAudio(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("sm", Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val mediaAttrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()
    private val uiAttrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    private val soundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(uiAttrs)
        .build()
    private val soundIds = HashMap<Int, Int>()
    private val loadedSoundIds = HashSet<Int>()
    private val activeSoundStreams = LinkedHashSet<Int>()

    private var loaded = false
    private var foreground = false
    private var homeVisible = true
    private var timeOffsetMinutes = 0
    private var focusHeld = false
    private var activePlayer: MediaPlayer? = null
    private var activeTrack: Int? = null
    private var clockCallback: Runnable? = null
    private var nextBurstCallback: Runnable? = null
    private var lastUiSoundAt = 0L
    private var lastSliderProgress = -100
    private var lastSliderTickAt = 0L

    private val focusRequest by lazy {
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(mediaAttrs)
            .setOnAudioFocusChangeListener { change ->
                when {
                    change <= AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                        focusHeld = false
                        stopAmbience()
                        stopUiSounds()
                    }
                    change == AudioManager.AUDIOFOCUS_GAIN && foreground -> {
                        focusHeld = true
                        refreshAmbience(force = true)
                    }
                }
            }.build()
    }

    fun startForeground() {
        foreground = true
        loadSounds()
        requestFocus()
        refreshAmbience(force = true)
        scheduleClockCheck()
    }

    fun stopForeground() {
        foreground = false
        clockCallback?.let { handler.removeCallbacks(it) }
        clockCallback = null
        stopAll()
        if (focusHeld) {
            audioManager.abandonAudioFocusRequest(focusRequest)
            focusHeld = false
        }
    }

    /** Ambient insect calls are restricted to the HOME page. UI clicks remain available on other tabs. */
    fun setHomeVisible(visible: Boolean) {
        if (homeVisible == visible) return
        homeVisible = visible
        if (!visible) stopAmbience() else refreshAmbience(force = true)
    }

    /** The HOME preview slider shifts the displayed clock; ambience follows that displayed time. */
    fun setTimeOffsetMinutes(minutes: Int) {
        if (timeOffsetMinutes == minutes) return
        timeOffsetMinutes = minutes
        if (foreground && homeVisible) refreshAmbience()
    }

    fun release() {
        stopForeground()
        soundPool.release()
        loaded = false
        loadedSoundIds.clear()
        soundIds.clear()
    }

    fun playButton() = playUi(R.raw.ui_button_tap_pixel)

    fun playSliderTick(progress: Int) {
        if (!enabledUi()) return
        val now = SystemClock.elapsedRealtime()
        if (abs(progress - lastSliderProgress) < 4 || now - lastSliderTickAt < 65L) return
        lastSliderProgress = progress
        lastSliderTickAt = now
        val id = when {
            progress < 34 -> R.raw.ui_slider_tick_low
            progress < 68 -> R.raw.ui_slider_tick_mid
            else -> R.raw.ui_slider_tick_high
        }
        playUi(id)
    }

    fun playSliderRelease() {
        if (enabledUi()) playUi(R.raw.ui_slider_release_confirm)
    }

    fun beginSliderDrag() {
        lastSliderProgress = -100
        lastSliderTickAt = 0L
    }

    fun updateVolumes() {
        if (!foreground) return
        if (!masterOn()) {
            stopAll()
            if (focusHeld) {
                audioManager.abandonAudioFocusRequest(focusRequest)
                focusHeld = false
            }
            return
        }
        if (!prefs.getBoolean("audio_ambience", true)) {
            stopAmbience()
        } else {
            updateActiveAmbienceVolume()
            refreshAmbience()
        }
    }

    private fun masterOn() = prefs.getBoolean("audio_master", true)
    private fun enabledUi() = foreground && masterOn() && prefs.getBoolean("audio_ui", true)
    private fun enabledAmbience() = foreground && homeVisible && masterOn() &&
        prefs.getBoolean("audio_ambience", true) && focusHeld

    private fun loadSounds() {
        if (loaded) return
        val resources = listOf(
            R.raw.ui_button_tap_pixel,
            R.raw.ui_slider_tick_low,
            R.raw.ui_slider_tick_mid,
            R.raw.ui_slider_tick_high,
            R.raw.ui_slider_release_confirm
        )
        soundPool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) loadedSoundIds.add(sampleId)
        }
        resources.forEach { resource -> soundIds[resource] = soundPool.load(app, resource, 1) }
        loaded = true
    }

    private fun playUi(resource: Int, retries: Int = 20) {
        if (!enabledUi()) return
        val now = SystemClock.elapsedRealtime()
        if (resource == R.raw.ui_button_tap_pixel && now - lastUiSoundAt < 75L) return

        val sampleId = soundIds[resource] ?: return
        if (sampleId !in loadedSoundIds) {
            if (retries > 0) handler.postDelayed({ playUi(resource, retries - 1) }, 60L)
            return
        }
        val volume = prefs.getInt("audio_ui_volume", 75).coerceIn(0, 100) / 100f
        val stream = soundPool.play(sampleId, volume, volume, 1, 0, 1f)
        if (stream > 0) {
            if (resource == R.raw.ui_button_tap_pixel) lastUiSoundAt = now
            activeSoundStreams.add(stream)
            while (activeSoundStreams.size > 16) activeSoundStreams.remove(activeSoundStreams.first())
        }
    }

    private fun stopUiSounds() {
        activeSoundStreams.toList().forEach { runCatching { soundPool.stop(it) } }
        activeSoundStreams.clear()
    }

    private fun requestFocus() {
        if (!masterOn() || focusHeld) return
        focusHeld = audioManager.requestAudioFocus(focusRequest) ==
            AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    /** 05:00-09:00 is deliberately quiet: only the three supplied insect recordings are used. */
    private fun scheduledTrack(): Int? {
        val shifted = Calendar.getInstance().apply { add(Calendar.MINUTE, timeOffsetMinutes) }
        val hour = shifted.get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 9..15 -> R.raw.insect_cicada
            in 16..18 -> R.raw.insect_higurashi
            in 19..23, in 0..4 -> R.raw.insect_suzumushi
            else -> null
        }
    }

    private fun scheduleClockCheck() {
        clockCallback?.let { handler.removeCallbacks(it) }
        val callback = object : Runnable {
            override fun run() {
                if (!foreground) return
                if (!masterOn()) stopAll()
                else refreshAmbience()
                handler.postDelayed(this, 5_000L)
            }
        }
        clockCallback = callback
        handler.postDelayed(callback, 30_000L)
    }

    private fun refreshAmbience(force: Boolean = false) {
        if (!foreground || !homeVisible || !masterOn() || !prefs.getBoolean("audio_ambience", true)) {
            stopAmbience()
            return
        }
        requestFocus()
        if (!focusHeld) {
            stopAmbience()
            return
        }

        val nextTrack = scheduledTrack()
        if (!force && nextTrack == activeTrack) {
            updateActiveAmbienceVolume()
            return
        }
        stopAmbience()
        activeTrack = nextTrack
        if (nextTrack != null) scheduleBurst(0L)
    }

    private fun scheduleBurst(delayMs: Long) {
        nextBurstCallback?.let { handler.removeCallbacks(it) }
        val callback = Runnable {
            nextBurstCallback = null
            playInsectBurst()
        }
        nextBurstCallback = callback
        handler.postDelayed(callback, delayMs)
    }

    private fun playInsectBurst() {
        if (!enabledAmbience()) return
        val track = activeTrack ?: return
        val player = runCatching { MediaPlayer.create(app, track) }.getOrNull() ?: run {
            scheduleBurst(4_500L)
            return
        }
        activePlayer = player
        player.setAudioAttributes(mediaAttrs)

        val masterVolume = prefs.getInt("audio_ambience_volume", 32).coerceIn(0, 100) / 100f
        val timeFactor = if (track == R.raw.insect_suzumushi &&
            Calendar.getInstance().apply { add(Calendar.MINUTE, timeOffsetMinutes) }.get(Calendar.HOUR_OF_DAY) !in 19..21) 0.58f else 1f
        val volume = (masterVolume * timeFactor).coerceIn(0f, 1f)
        player.setVolume(volume, volume)
        player.setOnCompletionListener {
            if (activePlayer === player) {
                activePlayer = null
                runCatching { player.release() }
                if (enabledAmbience() && activeTrack == track) scheduleBurst(4_500L)
            } else {
                runCatching { player.release() }
            }
        }
        player.setOnErrorListener { mp, _, _ ->
            if (activePlayer === mp) activePlayer = null
            runCatching { mp.release() }
            if (enabledAmbience() && activeTrack == track) scheduleBurst(4_500L)
            true
        }
        runCatching { player.start() }.onFailure {
            if (activePlayer === player) activePlayer = null
            runCatching { player.release() }
            if (enabledAmbience() && activeTrack == track) scheduleBurst(4_500L)
        }
    }

    private fun updateActiveAmbienceVolume() {
        val track = activeTrack ?: return
        val player = activePlayer ?: return
        val base = prefs.getInt("audio_ambience_volume", 32).coerceIn(0, 100) / 100f
        val factor = if (track == R.raw.insect_suzumushi &&
            Calendar.getInstance().apply { add(Calendar.MINUTE, timeOffsetMinutes) }.get(Calendar.HOUR_OF_DAY) !in 19..21) 0.58f else 1f
        runCatching { player.setVolume(base * factor, base * factor) }
    }

    private fun stopAmbience() {
        nextBurstCallback?.let { handler.removeCallbacks(it) }
        nextBurstCallback = null
        activeTrack = null
        val player = activePlayer
        activePlayer = null
        if (player != null) {
            runCatching { if (player.isPlaying) player.stop() }
            runCatching { player.release() }
        }
    }

    private fun stopAll() {
        stopAmbience()
        stopUiSounds()
    }
}
