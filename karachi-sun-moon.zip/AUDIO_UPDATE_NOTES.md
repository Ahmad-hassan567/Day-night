# QAMARIS intermittent insect audio update

## Behaviour
- No continuous ambience or looping insect bed.
- Each insect call is a 3.5-second pre-faded WAV clip, followed by 4.5 seconds of silence.
- 09:00-16:00 local time: Cicada.
- 16:00-19:00 local time: Higurashi.
- 19:00-05:00 local time: Suzumushi (reduced level from 22:00-05:00).
- 05:00-09:00 local time: silence; no fourth recording is used.
- Audio runs only while MainActivity is foreground. onPause stops ambience and UI streams.
- SunMoonWidget remains independent and silent.

## UI effects
- Pixel button tap uses ui_button_tap_pixel.
- Slider drag uses low/mid/high ticks at progress intervals with 65 ms throttling.
- Slider release uses ui_slider_release_confirm.
- SoundPool load-completion is tracked so early taps/drags are retried rather than silently lost.

## Source audio
Only the three user-attached insect recordings were converted to compact mono PCM WAV resources:
- insect_suzumushi.wav
- insect_cicada.wav
- insect_higurashi.wav

The previous five continuous ambience resources were removed. Existing five UI WAV effects were retained.

## Verification
- ZIP integrity and resource-reference consistency checked.
- All three insect WAVs checked: 22,050 Hz, mono, 16-bit PCM, 3.5 seconds.
- No audio APIs or AppAudio references in SunMoonWidget.kt; widget source hash unchanged.
- Android compilation and APK generation were not run: this workspace has no Gradle executable, Gradle wrapper, or Kotlin compiler/Android SDK.


## Follow-up fix (2026-11-23)
- Ambient insect audio is now restricted to the HOME tab only. Entering THEMES, STYLE, WIDGET, or SOUND stops the ambience immediately; returning HOME selects the correct track again.
- The HOME time-preview slider now shifts the audio schedule by the same simulated minutes as the visual sun/moon preview. Moving the slider into night selects Suzumushi; moving into evening selects Higurashi; moving into daytime selects Cicada.
- The app checks the effective time more frequently and updates the Suzumushi night volume when the preview clock changes.
- UI click and slider sounds remain separate from ambience and can work on the other tabs.
- Android SDK/Gradle are unavailable in this execution environment, so Kotlin compilation and APK generation have not been verified.

## Verification follow-up (2026-11-23)
- ZIP archive integrity re-tested: all entries pass `unzip -t` with no compressed-data errors.
- Static source review found and fixed a resume-order edge case: the selected tab is now applied before foreground audio starts, preventing a brief ambience burst when resuming on a non-HOME tab.
- Static checks confirm the HOME preview slider sends its simulated time offset to the audio scheduler, and ambience gating requires the HOME tab.
- A real Android/Gradle build and physical-device playback test remain outstanding because this environment has no Android SDK or Gradle wrapper/executable.
