package com.sunmoon.karachi

import android.content.Context
import android.graphics.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

object Renderer {
    private const val HZ = 0.755f
    /** One shared sun/moon path for every scenery: spans nearly the full width and peaks high in the sky. */
    private const val ARC_X0 = 0.06f
    private const val ARC_X1 = 0.94f
    private const val ARC_PEAK = 0.12f   // top edge of the body at noon, as a fraction of the height
    val TZ: TimeZone = TimeZone.getTimeZone("Asia/Karachi")
    private val K = arrayOf(
        Triple(-18.0, "#050816", "#0c1440"), Triple(-8.0, "#14184a", "#3a2a6a"),
        Triple(-2.0, "#3b2d7a", "#e0627a"), Triple(3.0, "#5a6fc0", "#ffa05a"),
        Triple(10.0, "#4a9fe0", "#ffd08a"), Triple(25.0, "#2f8fe6", "#9fd8f5"),
        Triple(90.0, "#1f7fe0", "#8fd3f7")
    )
    private val cache = HashMap<Int, Bitmap>()

    fun fmt(t: Long): String = SimpleDateFormat("h:mm a", Locale.US).apply { timeZone = TZ }.format(Date(t))

    /** Everything the app needs to know about one moment in time. */
    class Snap(val now: Long) {
        val sun = Astro.body(now, false)
        val moon = Astro.body(now, true)
        val alt = Astro.alt(now, false)
        val am = Calendar.getInstance(TZ).apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY) < 12
        val night = alt < -3
        val eve = !night && !am && alt <= 10
        val phase = if (night) "NIGHT" else if (am) "MORNING" else if (alt > 10) "AFTERNOON" else "EVENING"
        fun pick(up: Boolean, moonBody: Boolean): String {
            val d = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = TZ }
            val b = if (moonBody) moon else sun
            return b.ev.firstOrNull { it.up == up && d.format(Date(it.t)) == d.format(Date(now)) }?.let { fmt(it.t) } ?: "--"
        }
        /** (tile index 0..3 = sunrise, sunset, moonrise, moonset, time, countdown text) */
        fun next(): Triple<Int, Long, String>? {
            val c = listOfNotNull(
                sun.next?.let { Triple(if (it.up) 0 else 1, it.t, if (it.up) "Sunrise" else "Sunset") })
            return c.minByOrNull { it.second }
        }
    }

    fun snap(now: Long) = Snap(now)

    private fun mix(a: Int, b: Int, k: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt())

    private val KI by lazy { K.map { Triple(it.first, Color.parseColor(it.second), Color.parseColor(it.third)) } }

    /** 0 = automatic (original colour); otherwise the colour the user picked. */
    fun custom(ctx: Context, key: String) = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt(key, 0)
    private fun tinted(ctx: Context, key: String): ColorFilter? {
        val c = custom(ctx, key)
        return if (c == 0) null else PorterDuffColorFilter(Color.argb(170, Color.red(c), Color.green(c), Color.blue(c)), PorterDuff.Mode.SRC_ATOP)
    }
    fun blinkStrength(ctx: Context): Float {
        val i = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt("bstr", 1).coerceIn(0, 2)
        return floatArrayOf(0.15f, 0.35f, 0.60f)[i]
    }
    val COLOR_KEYS = listOf("c_sky_day", "c_sky_eve", "c_sky_night", "c_sun", "c_moon", "c_stars", "c_lights")
    fun colorKey(ctx: Context) = COLOR_KEYS.joinToString(",") { custom(ctx, it).toString() } + "|" + blinkStrength(ctx)

    private fun skyTable(ctx: Context): List<Triple<Double, Int, Int>> {
        val day = custom(ctx, "c_sky_day"); val eve = custom(ctx, "c_sky_eve"); val night = custom(ctx, "c_sky_night")
        if (day == 0 && eve == 0 && night == 0) return KI
        val t = KI.toMutableList()
        fun dark(c: Int, f: Float) = mix(c, Color.BLACK, 1 - f)
        if (night != 0) { t[0] = Triple(-18.0, dark(night, .45f), dark(night, .8f)); t[1] = Triple(-8.0, dark(night, .6f), night) }
        if (eve != 0) {
            t[2] = Triple(-2.0, dark(eve, .5f), eve); t[3] = Triple(3.0, dark(eve, .7f), eve)
            t[4] = Triple(10.0, dark(eve, .9f), mix(eve, Color.WHITE, .35f))
        }
        if (day != 0) { t[5] = Triple(25.0, dark(day, .85f), mix(day, Color.WHITE, .3f)); t[6] = Triple(90.0, dark(day, .75f), mix(day, Color.WHITE, .2f)) }
        return t
    }

    private fun sky(a0: Double, ctx: Context): Pair<Int, Int> {
        val T = skyTable(ctx)
        val a = max(-18.0, a0)
        var i = 1
        while (i < T.size - 1 && a > T[i].first) i++
        val x = T[i - 1]; val y = T[i]
        val k = ((a - x.first) / (y.first - x.first)).coerceIn(0.0, 1.0).toFloat()
        return Pair(mix(x.second, y.second, k), mix(x.third, y.third, k))
    }

    private fun bmp(ctx: Context, id: Int): Bitmap = cache.getOrPut(id) {
        BitmapFactory.decodeResource(ctx.resources, id, BitmapFactory.Options().apply { inScaled = false })
    }

    /** Scene only: sky, stars, sun, moon, shore. No text. */
    /** name to (hue degrees, saturation, brightness) applied to the shore image only */
    val THEMES = listOf(
        "Original" to floatArrayOf(0f, 1f, 1f), "Pastel" to floatArrayOf(0f, .55f, 1.1f),
        "Vivid" to floatArrayOf(0f, 1.4f, 1f), "Sakura" to floatArrayOf(240f, 1f, 1f),
        "Vaporwave" to floatArrayOf(90f, 1f, 1f))

    /** corner radius as a fraction of widget/scene width */
    val ROUNDS = listOf("Square" to 0f, "Slight" to 0.045f, "Medium" to 0.08f, "Round" to 0.13f)

    fun round(ctx: Context) = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt("round", 1).coerceIn(0, ROUNDS.size - 1)
    fun radiusFrac(ctx: Context) = ROUNDS[round(ctx)].second

    fun theme(ctx: Context) = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt("theme", 0).coerceIn(0, THEMES.size - 1)

    private fun themeFilter(i: Int): ColorFilter? = if (i == 0) null else ColorMatrixColorFilter(themeMatrix(i))

    private fun themeMatrix(i: Int): ColorMatrix {
        if (i == 0) return ColorMatrix()
        val (h, sat, br) = THEMES[i].second.let { Triple(it[0], it[1], it[2]) }
        val a = cos(h * PI / 180).toFloat(); val b = sin(h * PI / 180).toFloat()
        val cm = ColorMatrix(); cm.setSaturation(sat)
        cm.postConcat(ColorMatrix(floatArrayOf(
            .213f + .787f * a - .213f * b, .715f - .715f * a - .715f * b, .072f - .072f * a + .928f * b, 0f, 0f,
            .213f - .213f * a + .143f * b, .715f + .285f * a + .140f * b, .072f - .072f * a - .283f * b, 0f, 0f,
            .213f - .213f * a - .787f * b, .715f - .715f * a + .715f * b, .072f + .928f * a + .072f * b, 0f, 0f,
            0f, 0f, 0f, 1f, 0f)))
        cm.postConcat(ColorMatrix(floatArrayOf(br, 0f, 0f, 0f, 0f, 0f, br, 0f, 0f, 0f, 0f, 0f, br, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
        return cm
    }

    private fun pref(ctx: Context, k: String) = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt(k, 0)
    fun animated(ctx: Context) = pref(ctx, "anim") == 0
    fun blink(ctx: Context) = pref(ctx, "lights") == 1 && animated(ctx)
    fun starsAnim(ctx: Context) = pref(ctx, "stars") == 0
    fun waves(ctx: Context) = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt("waves", 1).coerceIn(0, 2)
    /** -1 = AUTO; otherwise 0..100 chosen with the slider. */
    fun darkRaw(ctx: Context) = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt("dark", -1)
    /** How dark scenes get at night (1 = original darkness). AUTO picks a value from the picture's own brightness. */
    fun darkK(ctx: Context, lum: Float): Float {
        val p = darkRaw(ctx)
        return if (p < 0) (0.35f + (lum - 70f) / 100f).coerceIn(0.45f, 0.8f) else p.coerceIn(0, 100) / 100f
    }
    fun stateKey(ctx: Context): String =
        "${scenery(ctx)}|${variantIndex(ctx)}|${theme(ctx)}|${round(ctx)}|${animated(ctx)}|${blink(ctx)}|${starsAnim(ctx)}|${shadow(ctx)}|${waves(ctx)}|${darkRaw(ctx)}|${colorKey(ctx)}"
    fun shadow(ctx: Context) = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt("shadow", 1).coerceIn(0, 2)

    fun needsFrames(ctx: Context, s: Snap): Boolean {
        val v = variant(ctx)
        if (starsOn(s) && starsAnim(ctx)) return true
        if (!animated(ctx)) return false
        val bodyUp = s.sun.p != null || s.moon.p != null
        val water = v != null && Profiles.get(ctx, v.key)?.water != null
        return v?.petals != null || (blink(ctx) && s.alt < 3 && v != null) || (shadow(ctx) > 0 && bodyUp) || (waves(ctx) > 0 && water)
    }

    val SCENERY: List<String> = listOf("Beach") + Registry.ALL.map { it.name }
    fun scenery(ctx: Context) = pref(ctx, "scenery").coerceIn(0, SCENERY.size - 1)
    fun variantIndex(ctx: Context, sc: Int = scenery(ctx)): Int =
        if (sc == 0) 0 else pref(ctx, "var_$sc").coerceIn(0, Registry.ALL[sc - 1].vs.size - 1)
    fun variant(ctx: Context): Registry.V? {
        val sc = scenery(ctx)
        return if (sc == 0) null else Registry.ALL[sc - 1].vs[variantIndex(ctx, sc)]
    }

    // Only the current scene (image + glow layer) stays in memory.
    private var curKey: String? = null
    private var curImg: Bitmap? = null
    private var curGlow: Bitmap? = null

    private fun loadAsset(ctx: Context, name: String, sample: Int = 1): Bitmap? = try {
        ctx.assets.open("scenes/$name.webp").use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        }
    } catch (e: Exception) { null }

    @Synchronized
    private fun sceneImages(ctx: Context, key: String): Pair<Bitmap, Bitmap?>? {
        if (curKey != key) { curImg = loadAsset(ctx, key); curGlow = loadAsset(ctx, key + "_g"); curKey = key }
        return curImg?.let { Pair(it, curGlow) }
    }

    fun thumb(ctx: Context, key: String): Bitmap? = loadAsset(ctx, key, 4)

    /** One evening image per scene: recolour by sun altitude (day = brighter/cooler, night = dark/blue). Bright images get darkened more at night. */
    private fun phaseMatrix(a: Double, lum: Float, kd: Float): ColorMatrix {
        val n = ((3 - a) / 8).coerceIn(0.0, 1.0).toFloat() * kd; val d = ((a - 3) / 10).coerceIn(0.0, 1.0).toFloat()
        val dk = ((lum - 110f) / 70f).coerceIn(0f, 1f)
        val r = 1f + d * 0.10f * (1 - dk * 0.6f) - n * (0.58f + 0.10f * dk)
        val g = 1f + d * 0.22f * (1 - dk * 0.6f) - n * (0.50f + 0.10f * dk)
        val b = 1f + d * 0.30f * (1 - dk * 0.6f) - n * (0.15f + 0.05f * dk)
        val cm = ColorMatrix(); cm.setSaturation(1f - n * 0.15f - d * 0.1f)
        cm.postConcat(ColorMatrix(floatArrayOf(r, 0f, 0f, 0f, 0f, 0f, g, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
        return cm
    }

    fun starsOn(s: Snap) = ((-s.alt - 2) / 8) > 0 && !(s.moon.p != null && s.alt > 0)

    fun scene(ctx: Context, W: Int, H: Int, s: Snap, frame0: Int = 0, radius: Float = 0f): Bitmap {
        val frame = if (animated(ctx)) frame0 else 0
        val sframe = if (starsAnim(ctx)) frame0 else 0
        val blink = blink(ctx)
        val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val np = Paint().apply { isFilterBitmap = false }
        val a = s.alt

        val (top, bot) = sky(a, ctx)
        p.shader = LinearGradient(0f, 0f, 0f, H.toFloat(), top, bot, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p); p.shader = null

        val v0 = variant(ctx)
        val imgs = if (v0 != null) sceneImages(ctx, v0.key) else null
        val v = if (imgs != null) v0 else null
        val shore: Bitmap = imgs?.first
            ?: bmp(ctx, if (s.night) R.drawable.shore_night else if (s.eve) R.drawable.shore_eve else R.drawable.shore_day)
        val hz = v?.hz ?: HZ
        val shoreFull = W.toFloat() * shore.height / shore.width
        val shoreH = min(shoreFull, H * 0.85f)           // very tall scenes lose a little of their top in small widgets
        val cropFrac = (shoreFull - shoreH) / shoreFull
        val hor = H - shoreFull * (1 - hz)
        val dst = RectF(0f, H - shoreH, W.toFloat(), H.toFloat())

        val so = ((-a - 2) / 8).coerceIn(0.0, 1.0)
        if (so > 0 && !(s.moon.p != null && a > 0)) {
            val sp = Paint().apply { alpha = (so * 255).toInt(); colorFilter = tinted(ctx, "c_stars") }
            val ids = intArrayOf(R.drawable.star0, R.drawable.star1, R.drawable.star2, R.drawable.star3, R.drawable.star4, R.drawable.star5)
            for (i in 0 until 14) {
                val st = bmp(ctx, ids[i % 6])
                val w = W * (if (i % 3 == 0) 0.04f else 0.028f); val h = w * st.height / st.width
                val x = W * (0.07f + ((i * 37) % 86) / 100f); val y = H * (0.05f + ((i * 23) % 38) / 100f * 0.8f)
                val k = floatArrayOf(1f, 0.7f, 0.4f)[(i + sframe) % 3]
                val cx = x + w / 2; val cy = y + h / 2
                sp.alpha = (so * (0.45 + 0.55 * k) * 255).toInt()
                c.drawBitmap(st, null, RectF(cx - w * k / 2, cy - h * k / 2, cx + w * k / 2, cy + h * k / 2), sp)
            }
        }

        val px0 = ARC_X0; val px1 = ARC_X1
        fun place(b: Bitmap, w: Float, pr: Double?, glow: Int, tint: ColorFilter?) {
            if (pr == null) return
            val h = w * b.height / b.width
            val x = W * (px0 + (px1 - px0) * pr.toFloat())
            val amp = max(hor - H * ARC_PEAK, hor * 0.5f)
            val y = hor + h / 2 - sin(PI * pr).toFloat() * amp
            val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(x, y, w * 1.1f, glow, Color.TRANSPARENT, Shader.TileMode.CLAMP) }
            c.drawCircle(x, y, w * 1.1f, gp)
            c.drawBitmap(b, null, RectF(x - w / 2, y - h / 2, x + w / 2, y + h / 2), Paint().apply { isFilterBitmap = false; colorFilter = tint })
        }
        val cm = custom(ctx, "c_moon"); val cs = custom(ctx, "c_sun")
        place(bmp(ctx, R.drawable.moon), W * 0.075f, s.moon.p,
            if (cm != 0) Color.argb(90, Color.red(cm), Color.green(cm), Color.blue(cm)) else Color.argb(90, 220, 210, 255), tinted(ctx, "c_moon"))
        place(bmp(ctx, R.drawable.sun), W * 0.105f, s.sun.p,
            if (cs != 0) Color.argb(110, Color.red(cs), Color.green(cs), Color.blue(cs)) else Color.argb(110, 255, 200, 70), tinted(ctx, "c_sun"))

        val shp = Paint().apply { isFilterBitmap = false
            colorFilter = if (v != null) ColorMatrixColorFilter(ColorMatrix(themeMatrix(theme(ctx))).apply { postConcat(phaseMatrix(a, v.lum, darkK(ctx, v.lum))) })
                          else themeFilter(theme(ctx)) }
        c.drawBitmap(shore, Rect(0, (cropFrac * shore.height).toInt(), shore.width, shore.height), dst, shp)

        // water: waves + sun/moon shine; ground band: cast shadows
        val nf = ((3 - a) / 8).coerceIn(0.0, 1.0).toFloat()
        val prof = if (v != null) Profiles.get(ctx, v.key) else null
        val wtr = prof?.water ?: if (v == null) floatArrayOf(0.37f, 1f, HZ, 0.97f) else null
        val wv = waves(ctx)
        if (v != null && wtr != null && wv > 0) {
            val ywt = H - shoreFull * (1 - wtr[2]); val ywb = H - shoreFull * (1 - wtr[3])
            val gap = max(4f, W * 0.012f); val rows = ((ywb - ywt) / gap).toInt()
            val wp = Paint()
            val baseA = (if (wv == 2) 80 else 42) * (1f - 0.45f * nf)
            c.save(); c.clipRect(W * wtr[0], ywt, W * wtr[1], ywb)
            for (rr in 0 until rows) {
                val y = ywt + rr * gap + gap * 0.35f
                val segW = W * (0.03f + 0.02f * ((rr * 7) % 5) / 4f); val period = segW * 2.2f
                val dir = if (rr % 2 == 0) 1f else -1f
                var x = W * wtr[0] - period + ((frame / 3f) * period * dir + period * 3) % period + (rr * W * 0.037f) % period
                wp.color = Color.argb((baseA * (0.65f + 0.35f * (rr % 2))).toInt().coerceIn(0, 255), 215, 235, 255)
                while (x < W * wtr[1]) { c.drawRect(x, y, x + segW, y + max(2f, gap * 0.22f), wp); x += period }
            }
            c.restore()
        }
        val shMode = shadow(ctx)
        if (shMode > 0) {
            val sunUp = s.sun.p != null && a > 0
            val body: Double? = if (sunUp) s.sun.p else s.moon.p
            if (body != null) {
                val bx = W * (px0 + (px1 - px0) * body.toFloat())
                val strength = (if (sunUp) 0.30f * min(1f, (a / 5).toFloat() + 0.25f) else 0.16f) * (if (shMode == 2) 1.35f else 1f)
                if (wtr != null && bx > W * wtr[0] && bx < W * wtr[1]) {
                    val ywt = H - shoreFull * (1 - wtr[2]); val ywb = H - shoreFull * (1 - wtr[3])
                    val rowH = max(2f, W * 0.006f)
                    val rows = ((ywb - ywt) / (rowH * 1.7f)).toInt().coerceIn(1, 40)
                    c.save(); c.clipRect(W * wtr[0], ywt, W * wtr[1], ywb)
                    val rp = Paint()
                    for (rr in 0 until rows) {
                        val y = ywt + rr * rowH * 1.7f
                        val fall = 1f - rr.toFloat() / rows
                        val ww = (W * 0.012f + rr * rowH * 0.5f) * (1f + 0.35f * sin(rr * 1.7f + frame * 2.1f))
                        val xx = bx + sin(rr * 0.9f + frame * 1.7f) * rowH
                        val al = (255 * strength * 2.1f * fall).toInt().coerceIn(0, 255)
                        rp.color = if (sunUp) Color.argb(al, 255, 215, 130) else Color.argb(al, 215, 225, 255)
                        c.drawRect(xx - ww / 2, y, xx + ww / 2, y + rowH, rp)
                    }
                    c.restore()
                }
                if (prof != null) {
                    val oh = prof.oh
                    val maxOh = (oh.maxOrNull() ?: 0f) * shoreFull
                    if (maxOh > 2f) {
                        val yb = H - 0.12f * shoreFull
                        val f = min(0.4f, 0.10f * shoreFull / maxOh)
                        val dir = if (body < 0.5) 1f else -1f
                        val kk = dir * (if (shMode == 2) 1.3f else 1f) * (0.45f + 1.5f * (1f - sin(PI * body).toFloat()))
                        val layer = c.saveLayerAlpha(0f, 0f, W.toFloat(), H.toFloat(), (strength * 255).toInt().coerceIn(0, 255))
                        c.clipRect(0f, yb, W.toFloat(), H.toFloat())
                        val sp = Paint().apply { color = Color.BLACK }
                        val path = Path()
                        for (i in 0 until oh.size - 1) {
                            val h1 = oh[i] * shoreFull; val h2 = oh[i + 1] * shoreFull
                            if (h1 < 1f && h2 < 1f) continue
                            val x1 = W * i / (oh.size - 1f); val x2 = W * (i + 1) / (oh.size - 1f)
                            path.reset(); path.moveTo(x1, yb); path.lineTo(x2, yb)
                            path.lineTo(x2 + kk * h2, yb + f * h2); path.lineTo(x1 + kk * h1, yb + f * h1); path.close()
                            c.drawPath(path, sp)
                        }
                        c.restoreToCount(layer)
                    }
                }
            }
        }

        if (v != null) {
            val n = ((3 - a) / 8).coerceIn(0.0, 1.0).toFloat()
            val glow = imgs?.second
            if (n > 0f && glow != null) {
                val gp = Paint().apply { isFilterBitmap = true; colorFilter = tinted(ctx, "c_lights"); xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
                    alpha = (n * (if (blink) floatArrayOf(1f, 1f - blinkStrength(ctx), 1f - blinkStrength(ctx) / 2)[frame % 3] else 1f) * 210).toInt() }
                c.drawBitmap(glow, Rect(0, (cropFrac * glow.height).toInt(), glow.width, glow.height), dst, gp)
            }
            if (n > 0f && prof != null) {            // street-light beams reaching the ground
                val bp = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD) }
                val path = Path()
                for (b in prof.beams) {
                    val xc = W * b[0]; val yt = H - shoreFull * (1 - b[1]); val yb = H - shoreFull * (1 - b[2])
                    val ht = W * b[3] / 2; val hb = W * b[4] / 2
                    bp.shader = LinearGradient(0f, yt, 0f, yb, Color.argb((n * 125).toInt(), 255, 232, 160), Color.argb((n * 28).toInt(), 255, 232, 160), Shader.TileMode.CLAMP)
                    path.reset(); path.moveTo(xc - ht, yt); path.lineTo(xc + ht, yt); path.lineTo(xc + hb, yb); path.lineTo(xc - hb, yb); path.close()
                    c.drawPath(path, bp)
                    bp.shader = RadialGradient(xc, yt, W * 0.035f, Color.argb((n * 190).toInt(), 255, 240, 190), Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    c.drawCircle(xc, yt, W * 0.035f, bp)
                }
            }
            val pet = v.petals
            if (pet != null && animated(ctx)) {          // falling petals; 3 frames loop seamlessly
                val top0 = H - shoreFull
                val step = H * 0.035f; val per = step * 3
                val pTop = top0 + shoreFull * pet[2] * 0.9f; val pBot = top0 + shoreFull * 0.93f; val ps = W * 0.0065f
                val pp = Paint().apply { colorFilter = shp.colorFilter }
                for (lane in 0 until 7) {
                    val bx = W * (pet[0] + (pet[1] - pet[0]) * ((lane * 37) % 7) / 7f)
                    val y0 = pTop + ((lane * 0.37f) % 1f) * per + frame * step
                    for (k in 0..9) {
                        val y = y0 + k * per
                        if (y >= pBot) break
                        val x = bx + sin(lane + y / (H * 0.05f)) * W * 0.012f
                        pp.color = if ((lane + k) % 2 == 0) Color.rgb(255, 158, 203) else Color.rgb(255, 205, 225)
                        c.drawRect(x, y, x + ps, y + ps, pp)
                    }
                }
            }
        }
        if (radius <= 0f) return out
        val res = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val rc = Canvas(res)
        rc.drawRoundRect(RectF(0f, 0f, W.toFloat(), H.toFloat()), radius, radius, Paint(Paint.ANTI_ALIAS_FLAG))
        rc.drawBitmap(out, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN) })
        return res
    }
}
