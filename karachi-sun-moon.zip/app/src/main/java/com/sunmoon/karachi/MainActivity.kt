package com.sunmoon.karachi

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var view: AppView
    private val marks = ArrayList<() -> Unit>()
    private lateinit var pvThemes: ScenePreview
    private lateinit var pvStyle: ScenePreview
    private lateinit var listBox: LinearLayout
    private val thumbs = HashMap<Int, Bitmap?>()
    private var moreOpen = false
    private var appAudio: AppAudio? = null
    private var selectedTab: Int = 0

    private fun prefs() = getSharedPreferences("sm", Context.MODE_PRIVATE)
    private fun d() = resources.displayMetrics.density
    private fun dp(v: Float) = (v * d()).toInt()
    private val tick = object : Runnable { override fun run() { view.invalidate(); pvThemes.off = view.off; pvStyle.off = view.off; pvThemes.invalidate(); pvStyle.invalidate(); h.postDelayed(this, 350) } }

    private fun changed() { rebuildList(); view.invalidate(); SunMoonWidget.refreshAll(this); marks.forEach { it() } }

    private fun title(t: String) = PixelText(this, t, 2f * d(), UI.INK)
    private fun hint(t: String) = TextView(this).apply { text = t; setTextColor(UI.MUTE); textSize = 12f }
    private fun lp(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14f), top, dp(14f), bottom) }
    private fun btnLp() = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8f) }

    /** Titled row of PixelButtons stored in prefs under [key]. */
    private fun options(t: String, hintText: String?, names: List<String>, key: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(title(t.uppercase()), lp(dp(26f), dp(12f)))
        if (hintText != null) box.addView(hint(hintText), lp(0, dp(12f)))
        val row = LinearLayout(this).apply { setPadding(dp(14f), 0, dp(14f), 0) }
        val btns = ArrayList<PixelButton>()
        val def = if (key == "round" || key == "shadow" || key == "bstr" || key == "waves") 1 else 0
        fun mark() { val cur = prefs().getInt(key, def); btns.forEachIndexed { i, b -> b.on = i == cur } }
        names.forEachIndexed { i, n ->
            val b = PixelButton(this, n.uppercase())
            b.setOnClickListener { prefs().edit().putInt(key, i).apply(); changed() }
            btns.add(b); row.addView(b, btnLp())
        }
        mark(); marks.add { mark() }
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        return box
    }

    /** Scenery list; the variant buttons (THEME 1/2/3) open right under the selected scenery. */
    private fun rebuildList() {
        listBox.removeAllViews()
        listBox.addView(title("SCENERY"), lp(dp(26f), dp(12f)))
        val cur = Renderer.scenery(this)
        val firstMore = Registry.ALL.indexOfFirst { it.more } + 1   // 0 = there is no MORE group
        Renderer.SCENERY.forEachIndexed { i, name ->
            if (firstMore > 0 && i == firstMore) {
                val mb = PixelButton(this, if (moreOpen) "LESS" else "MORE...")
                mb.setOnClickListener { moreOpen = !moreOpen; rebuildList() }
                listBox.addView(mb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14f), dp(6f), dp(14f), dp(12f)) })
            }
            if (firstMore > 0 && i >= firstMore && !moreOpen) return@forEachIndexed
            val th = thumbs.getOrPut(i) {
                if (i == 0) BitmapFactory.decodeResource(resources, R.drawable.shore_eve, BitmapFactory.Options().apply { inSampleSize = 4 })
                else Renderer.thumb(this, Registry.ALL[i - 1].vs[0].key)
            }
            val cnt = if (i == 0) 1 else Registry.ALL[i - 1].vs.size
            val r = SceneryRow(this, name.uppercase(), th, cnt)
            r.on = i == cur
            r.setOnClickListener { prefs().edit().putInt("scenery", i).apply(); changed() }
            listBox.addView(r, lp(0, dp(10f)))
            if (i == cur && i > 0 && cnt > 1) {
                val row = LinearLayout(this).apply { setPadding(dp(14f), dp(2f), dp(14f), dp(14f)) }
                val vi = Renderer.variantIndex(this)
                for (k in 0 until cnt) {
                    val b = PixelButton(this, "THEME ${k + 1}"); b.on = k == vi
                    b.setOnClickListener { prefs().edit().putInt("var_$i", k).apply(); changed() }
                    row.addView(b, btnLp())
                }
                listBox.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
            }
        }
    }

    /** Slider 0..100 stored under [key] with an AUTO button (-1 = automatic). The preview updates while dragging. */
    private fun slider(t: String, hintText: String, key: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL }
        val label = PixelText(this, "", 2f * d(), UI.INK)
        val auto = PixelButton(this, "AUTO")
        head.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(auto, LinearLayout.LayoutParams(-2, -2))
        box.addView(head, lp(dp(26f), dp(10f)))
        box.addView(hint(hintText), lp(0, dp(8f)))
        val sb = SeekBar(this).apply {
            max = 100; progress = prefs().getInt(key, -1).let { if (it < 0) 65 else it }
            progressTintList = ColorStateList.valueOf(UI.ACC); thumbTintList = ColorStateList.valueOf(UI.ACC)
        }
        fun refresh() {
            val p = prefs().getInt(key, -1)
            auto.on = p < 0
            label.text = t.uppercase() + " " + (if (p < 0) "AUTO" else p.toString())
        }
        refresh(); marks.add { refresh() }
        auto.setOnClickListener { prefs().edit().putInt(key, -1).apply(); changed() }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                if (u) { prefs().edit().putInt(key, p).apply(); refresh(); appAudio?.playSliderTick(p) }
            }
            override fun onStartTrackingTouch(s: SeekBar) { appAudio?.beginSliderDrag() }
            override fun onStopTrackingTouch(s: SeekBar) { appAudio?.playSliderRelease(); SunMoonWidget.refreshAll(this@MainActivity) }
        })
        box.addView(sb, lp(0, dp(4f)))
        return box
    }

    /** One row: label + AUTO + colour swatches. Stored under [key] (0 = automatic). */
    private fun colorRow(label: String, key: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(PixelText(this, label, 1.7f * d(), UI.MUTE), lp(dp(14f), dp(8f)))
        val row = LinearLayout(this).apply { setPadding(dp(14f), 0, dp(14f), 0); gravity = android.view.Gravity.CENTER_VERTICAL }
        val auto = PixelButton(this, "AUTO")
        auto.setOnClickListener { prefs().edit().putInt(key, 0).apply(); changed() }
        row.addView(auto, btnLp())
        val sws = ArrayList<Swatch>()
        UI.PALETTE.forEach { col ->
            val s = Swatch(this, col)
            s.setOnClickListener { prefs().edit().putInt(key, col).apply(); changed() }
            sws.add(s); row.addView(s, btnLp())
        }
        marks.add { val cur = prefs().getInt(key, 0); auto.on = cur == 0; sws.forEachIndexed { i, s -> s.on = UI.PALETTE[i] == cur } }
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        return box
    }

    private fun customColours(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(title("CUSTOM COLOURS"), lp(dp(26f), dp(12f)))
        box.addView(hint("AUTO keeps the original colour. Pick a swatch to change it (widget + app)."), lp(0, dp(8f)))
        listOf("SKY - DAY" to "c_sky_day", "SKY - EVENING" to "c_sky_eve", "SKY - NIGHT" to "c_sky_night",
            "SUN" to "c_sun", "MOON" to "c_moon", "STARS" to "c_stars", "LIGHTS GLOW" to "c_lights")
            .forEach { (l, k) -> box.addView(colorRow(l, k)) }
        val reset = PixelButton(this, "RESET ALL COLOURS")
        reset.setOnClickListener { prefs().edit().apply { Renderer.COLOR_KEYS.forEach { remove(it) } }.apply(); changed() }
        box.addView(reset, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(14f), dp(18f), 0, 0) })
        return box
    }

    private fun soundSettings(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(title("SOUND SETTINGS"), lp(dp(26f), dp(10f)))
        box.addView(hint("Atmospheric audio plays only while this app is open. Widgets stay silent."), lp(0, dp(18f)))
        fun toggle(label: String, key: String, default: Boolean) {
            val row = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(dp(14f), dp(5f), dp(14f), dp(5f)) }
            val text = PixelText(this, label, 1.55f * d(), UI.INK)
            val button = PixelButton(this, "")
            fun refresh() { val on = prefs().getBoolean(key, default); button.text = if (on) "ON" else "OFF"; button.on = on; text.text = label }
            button.setOnClickListener { val next = !prefs().getBoolean(key, default); prefs().edit().putBoolean(key, next).apply(); refresh(); appAudio?.updateVolumes() }
            row.addView(text, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(button)
            refresh(); box.addView(row); marks.add { refresh() }
        }
        toggle("MASTER AUDIO", "audio_master", true)
        toggle("NATURE AMBIENCE", "audio_ambience", true)
        toggle("UI PIXEL SOUNDS", "audio_ui", true)
        fun volume(labelText: String, key: String, default: Int) {
            box.addView(title(labelText), lp(dp(18f), dp(4f)))
            val value = PixelText(this, "", 1.5f * d(), UI.MUTE)
            val seek = SeekBar(this).apply {
                max = 100; progress = prefs().getInt(key, default).coerceIn(0, 100)
                progressTintList = ColorStateList.valueOf(UI.ACC); thumbTintList = ColorStateList.valueOf(UI.ACC)
            }
            fun refresh() { val v = prefs().getInt(key, default).coerceIn(0, 100); value.text = "$v%"; if (seek.progress != v) seek.progress = v }
            val head = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL; addView(value) }
            box.addView(head, lp(0, 0))
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, progress: Int, fromUser: Boolean) {
                    if (fromUser) { prefs().edit().putInt(key, progress).apply(); value.text = "$progress%"; appAudio?.updateVolumes(); appAudio?.playSliderTick(progress) }
                }
                override fun onStartTrackingTouch(s: SeekBar) { appAudio?.beginSliderDrag() }
                override fun onStopTrackingTouch(s: SeekBar) { appAudio?.playSliderRelease() }
            })
            box.addView(seek, lp(0, dp(12f)))
        }
        volume("AMBIENCE VOLUME", "audio_ambience_volume", 32)
        volume("UI SOUND VOLUME", "audio_ui_volume", 75)
        return box
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        view = AppView(this)
        val sb = SeekBar(this).apply { max = 288; progress = 144; setPadding(48, 8, 48, 32) }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) {
                view.off = (p - 144) * 5
                view.invalidate()
                appAudio?.setTimeOffsetMinutes(view.off)
                if (u) appAudio?.playSliderTick(p * 100 / 288)
            }
            override fun onStartTrackingTouch(s: SeekBar) { appAudio?.beginSliderDrag() }
            override fun onStopTrackingTouch(s: SeekBar) { appAudio?.playSliderRelease() }
        })
        view.onLive = { sb.progress = 144 }

        fun page(vararg v: View) = ScrollView(this).apply {
            addView(LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(28f)); v.forEach { addView(it) } })
        }

        pvThemes = ScenePreview(this); pvStyle = ScenePreview(this)
        fun pageP(pv: ScenePreview, vararg v: View): View = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(pv, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14f), dp(8f), dp(14f), dp(4f)) })
            addView(page(*v), LinearLayout.LayoutParams(-1, 0, 1f))
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val home = page(view, sb)
        val themes = pageP(pvThemes, listBox)
        val style = pageP(pvStyle,
            options("Colours", "Colour mood for the scenery.", Renderer.THEMES.map { it.first }, "theme"),
            slider("Night darkness", "AUTO picks a good level for each scene. Or drag: 0 = bright nights, 100 = darkest.", "dark"),
            options("Corner roundness", null, Renderer.ROUNDS.map { it.first }, "round"),
            options("Animation", "Still = no falling petals or moving water shine (saves battery).", listOf("Animated", "Still"), "anim"),
            options("Stars", "Twinkle or keep still. Works on its own, separate from Animation.", listOf("Twinkle", "Still"), "stars"),
            options("Lights", "Windows and lanterns glow at night. Blink needs Animation on.", listOf("Steady", "Blink"), "lights"),
            options("Blink strength", "How much the light dims while blinking: Low 15%, Medium 35%, High 60%.", listOf("Low 15%", "Medium 35%", "High 60%"), "bstr"),
            options("Waves", "Moving ripples on the water (water scenes only).", listOf("Off", "Soft", "Strong"), "waves"),
            options("Shadows", "Building shadows on the ground and sun/moon shine on water.", listOf("Off", "Soft", "Strong"), "shadow"),
            customColours())
        val sound = page(soundSettings())
        val pages = listOf(home, themes, style, sound)

        val frame = FrameLayout(this)
        pages.forEach { frame.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        val bar = LinearLayout(this).apply { setBackgroundColor(UI.BG); setPadding(dp(10f), dp(8f), dp(10f), dp(10f)) }
        val tabs = ArrayList<PixelButton>()
        fun show(i: Int) {
            selectedTab = i
            pages.forEachIndexed { j, p -> p.visibility = if (i == j) View.VISIBLE else View.GONE }
            tabs.forEachIndexed { j, t -> t.on = i == j }
            appAudio?.setHomeVisible(i == 0)
        }
        listOf("HOME", "THEMES", "STYLE", "SOUND").forEachIndexed { i, n ->
            val t = PixelButton(this, n, 1.7f, 1.5f); t.setOnClickListener { show(i) }
            tabs.add(t); bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3f), 0, dp(3f), 0) })
        }
        show(0)
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(UI.BG); fitsSystemWindows = true
            addView(frame, LinearLayout.LayoutParams(-1, 0, 1f)); addView(bar)
        })
        moreOpen = Registry.ALL.getOrNull(Renderer.scenery(this) - 1)?.more == true
        rebuildList(); marks.forEach { it() }
    }

    override fun onResume() {
        super.onResume()
        if (appAudio == null) appAudio = AppAudio(this)
        PixelButton.soundTap = { appAudio?.playButton() }
        // Set the selected page before foreground audio starts, so ambience can
        // never briefly start while the user is returning to a non-HOME tab.
        appAudio?.setHomeVisible(selectedTab == 0)
        appAudio?.setTimeOffsetMinutes(view.off)
        appAudio?.startForeground()
        tick.run()
    }
    override fun onPause() {
        appAudio?.stopForeground()
        PixelButton.soundTap = null
        super.onPause(); h.removeCallbacks(tick)
    }
    override fun onDestroy() {
        appAudio?.release(); appAudio = null
        super.onDestroy()
    }
}
