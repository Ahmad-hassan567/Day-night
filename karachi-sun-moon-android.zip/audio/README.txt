SUN / MOON WIDGET AUDIO PACK
Separate mono WAV files, 44.1 kHz.

AMBIENCE:
01 morning bird-like chirps (synthetic)
02 daytime cicada-style buzz
03 sunset Higurashi-style calls
04 nighttime Suzumushi-style bell tones
05 deep-night cricket-like ticks

UI:
06 8-bit pixel button tap
07 low slider tick
08 medium slider tick
09 high slider tick
10 slider-release confirmation blip

These are synthesized effects, not field recordings. Crossfade ambience loops by 300–500 ms.
