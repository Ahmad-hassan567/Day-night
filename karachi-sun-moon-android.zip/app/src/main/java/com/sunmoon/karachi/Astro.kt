package com.sunmoon.karachi

import kotlin.math.*

object Astro {
    const val LAT = 24.8607
    const val LNG = 67.0011
    private const val R = PI / 180
    private val E = R * 23.4397

    class Ev(val t: Long, val up: Boolean)
    class Body(val ev: List<Ev>, val up: Boolean, val p: Double?, val next: Ev?)

    private fun jd(t: Long) = t / 86400000.0 - 0.5 + 2440588 - 2451545
    private fun ra(l: Double, b: Double) = atan2(sin(l) * cos(E) - tan(b) * sin(E), cos(l))
    private fun dc(l: Double, b: Double) = asin(sin(b) * cos(E) + cos(b) * sin(E) * sin(l))

    fun alt(t: Long, moon: Boolean): Double {
        val d = jd(t)
        val a: Double; val de: Double
        if (moon) {
            val L = R * (218.316 + 13.176396 * d); val M = R * (134.963 + 13.064993 * d); val F = R * (93.272 + 13.22935 * d)
            val l = L + R * 6.289 * sin(M); val b = R * 5.128 * sin(F)
            a = ra(l, b); de = dc(l, b)
        } else {
            val M = R * (357.5291 + 0.98560028 * d)
            val C = R * (1.9148 * sin(M) + 0.02 * sin(2 * M) + 0.0003 * sin(3 * M))
            val L = M + C + R * 102.9372 + PI
            a = ra(L, 0.0); de = dc(L, 0.0)
        }
        val h = R * (280.16 + 360.9856235 * d) + R * LNG - a
        val phi = R * LAT
        return asin(sin(phi) * sin(de) + cos(phi) * cos(de) * cos(h)) / R
    }

    fun body(now: Long, moon: Boolean): Body {
        val th = if (moon) 0.133 else -0.833
        val step = 300000L
        val ev = ArrayList<Ev>()
        var t = now - 36 * 3600000L
        var pa = alt(t, moon) - th
        t += step
        while (t <= now + 36 * 3600000L) {
            val a = alt(t, moon) - th
            if ((pa < 0) != (a < 0)) ev.add(Ev((t - step + step * (-pa) / (a - pa)).toLong(), a > 0))
            pa = a; t += step
        }
        val up = alt(now, moon) - th > 0
        var p: Double? = null
        if (up) {
            val r = ev.lastOrNull { it.up && it.t <= now }
            val s = ev.firstOrNull { !it.up && it.t > now }
            if (r != null && s != null) p = (now - r.t).toDouble() / (s.t - r.t)
        }
        return Body(ev, up, p, ev.firstOrNull { it.t > now })
    }
}
