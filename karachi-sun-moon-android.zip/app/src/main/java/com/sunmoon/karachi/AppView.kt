package com.sunmoon.karachi

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

class AppView(ctx: Context) : View(ctx) {
    var off = 0            // test offset in minutes
    var onLive: (() -> Unit)? = null
    private val BG = Color.parseColor("#0d1026"); private val CARD = Color.parseColor("#171b3a")
    private val LINE = Color.parseColor("#2a2f5c"); private val INK = Color.parseColor("#f4ecd8")
    private val MUTE = Color.parseColor("#9a9cc4"); private val ACC = Color.parseColor("#ffb347")
    private val p = Paint()
    private var sceneBmp: Bitmap? = null; private var sceneKey = -1L
    private var sceneRect = RectF()

    override fun onMeasure(w: Int, h: Int) {
        val W = MeasureSpec.getSize(w); setMeasuredDimension(W, (W * 1.12f).toInt())
    }

    override fun onDraw(c: Canvas) {
        val W = width.toFloat(); val u = W / 100f
        val now = System.currentTimeMillis() + off * 60000L
        val s = Renderer.snap(now)
        c.drawColor(BG)

        // header
        PixelFont.draw(c, "KARACHI", 2 * u, 3 * u, 0.6f * u, INK)
        val bx = 2 * u + PixelFont.width("KARACHI", 0.6f * u) + 2.5f * u
        val bw = PixelFont.width(s.phase, 0.45f * u)
        p.color = ACC; c.drawRect(bx, 2.6f * u, bx + bw + 3 * u, 2.6f * u + 7 * 0.45f * u + 1.6f * u, p)
        PixelFont.draw(c, s.phase, bx + 1.5f * u, 3.4f * u, 0.45f * u, Color.parseColor("#1a1020"))
        PixelFont.draw(c, Renderer.fmt(now), 98 * u, 2.2f * u, 0.85f * u, INK, 1)

        // scene
        val sw = W - 4 * u; val sh = sw / 1.6f
        sceneRect.set(2 * u, 11 * u, 2 * u + sw, 11 * u + sh)
        val key = now / 60000L
        if (sceneBmp == null || key != sceneKey) { sceneBmp = Renderer.scene(context, 800, 500, s); sceneKey = key }
        c.drawBitmap(sceneBmp!!, null, sceneRect, Paint().apply { isFilterBitmap = false })
        p.style = Paint.Style.STROKE; p.strokeWidth = 0.4f * u; p.color = LINE; c.drawRect(sceneRect, p); p.style = Paint.Style.FILL

        // next event
        val nx = s.next()
        if (nx != null) {
            val m = ((nx.second - now) / 60000).toInt()
            PixelFont.draw(c, "AGLA: ${nx.third} ${Renderer.fmt(nx.second)} (${m / 60}H ${m % 60}M)", 2 * u, sceneRect.bottom + 2.5f * u, 0.45f * u, MUTE)
        }

        // tiles
        val names = arrayOf("SUNRISE", "SUNSET", "MOONRISE", "MOONSET")
        val times = arrayOf(s.pick(true, false), s.pick(false, false), s.pick(true, true), s.pick(false, true))
        val tw = (W - 6 * u) / 2; val th = 9 * u; val ty = sceneRect.bottom + 8 * u
        for (i in 0..3) {
            val x = 2 * u + (i % 2) * (tw + 2 * u); val y = ty + (i / 2) * (th + 2 * u)
            p.color = CARD; c.drawRect(x, y, x + tw, y + th, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 0.5f * u; p.color = if (nx?.first == i) ACC else LINE
            c.drawRect(x, y, x + tw, y + th, p); p.style = Paint.Style.FILL
            PixelFont.draw(c, names[i], x + 2 * u, y + 1.8f * u, 0.4f * u, MUTE)
            PixelFont.draw(c, times[i], x + 2 * u, y + 4.8f * u, 0.55f * u, INK)
        }
        val lbl = if (off == 0) "LIVE - TEST: SLIDER SE WAQT BADLEIN" else
            "TEST ${if (off > 0) "+" else "-"}${Math.abs(off) / 60}H ${Math.abs(off) % 60}M - SCENE PAR TAP = LIVE"
        PixelFont.draw(c, lbl, 2 * u, ty + 2 * (th + 2 * u) + 1 * u, 0.36f * u, MUTE)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP && sceneRect.contains(e.x, e.y)) onLive?.invoke()
        return true
    }
}
