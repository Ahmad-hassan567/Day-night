package com.sunmoon.karachi

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.min

object UI {
    val BG = Color.parseColor("#0d1026"); val CARD = Color.parseColor("#171b3a")
    val LINE = Color.parseColor("#2a2f5c"); val INK = Color.parseColor("#f4ecd8")
    val MUTE = Color.parseColor("#9a9cc4"); val ACC = Color.parseColor("#ffb347")
    val PALETTE = listOf("#E53935", "#FB8C00", "#FFC107", "#FFEB3B", "#9CCC65", "#43A047", "#00ACC1", "#4FC3F7",
        "#1E88E5", "#3949AB", "#8E24AA", "#EC407A", "#FFFFFF", "#90A4AE").map { Color.parseColor(it) }
}

/** Colour square for the custom-colour rows. */
class Swatch(ctx: Context, private val color: Int) : View(ctx) {
    var on = false
        set(v) { field = v; invalidate() }
    private val d = resources.displayMetrics.density
    private val p = Paint()
    init { isClickable = true }
    override fun performClick(): Boolean { if (isEnabled) PixelButton.soundTap?.invoke(); return super.performClick() }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension((32 * d).toInt(), (30 * d).toInt()) }
    override fun onDraw(c: Canvas) {
        p.style = Paint.Style.FILL; p.color = color; c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
        val sw = 2 * d
        p.style = Paint.Style.STROKE; p.strokeWidth = if (on) sw * 1.6f else sw; p.color = if (on) UI.ACC else UI.LINE
        c.drawRect(sw / 2, sw / 2, width - sw / 2, height - sw / 2, p)
    }
}

/** Plain label in the app's pixel font. */
class PixelText(ctx: Context, text0: String, private val ps: Float, private val color: Int) : View(ctx) {
    var text: String = text0
        set(v) { field = v; requestLayout(); invalidate() }
    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize(PixelFont.width(text, ps).toInt() + 1, w), (8 * ps).toInt())
    }
    override fun onDraw(c: Canvas) { PixelFont.draw(c, text, 0f, ps / 2, ps, color) }
}

/** Boxed pixel button, same look as the Sunrise/Sunset tiles. Border turns orange when selected. */
class PixelButton(ctx: Context, var text: String, scale: Float = 2f) : View(ctx) {
    var on = false
        set(v) { field = v; invalidate() }
    private val ps = scale * resources.displayMetrics.density
    private val p = Paint()
    init { isClickable = true }
    override fun performClick(): Boolean {
        if (isEnabled) soundTap?.invoke()
        return super.performClick()
    }
    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize((PixelFont.width(text, ps) + 10 * ps).toInt(), w), (15 * ps).toInt())
    }
    companion object { var soundTap: (() -> Unit)? = null }
    override fun onDraw(c: Canvas) {
        val W = width.toFloat(); val H = height.toFloat()
        p.style = Paint.Style.FILL; p.color = UI.CARD; c.drawRect(0f, 0f, W, H, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = ps; p.color = if (on) UI.ACC else UI.LINE
        c.drawRect(ps / 2, ps / 2, W - ps / 2, H - ps / 2, p)
        PixelFont.draw(c, text, W / 2, (H - 7 * ps) / 2, ps, if (on) UI.INK else UI.MUTE, 2)
    }
}

/** One scenery in the Themes list: thumbnail, name and how many variants it has. */
class SceneryRow(ctx: Context, private val name: String, private val thumb: Bitmap?, private val count: Int) : View(ctx) {
    var on = false
        set(v) { field = v; invalidate() }
    private val ps = 2f * resources.displayMetrics.density
    private val p = Paint(); private val np = Paint().apply { isFilterBitmap = false }
    init { isClickable = true }
    override fun performClick(): Boolean { if (isEnabled) PixelButton.soundTap?.invoke(); return super.performClick() }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(resolveSize(0, w), (30 * ps).toInt()) }
    override fun onDraw(c: Canvas) {
        val W = width.toFloat(); val H = height.toFloat(); val pad = 3 * ps
        p.style = Paint.Style.FILL; p.color = UI.CARD; c.drawRect(0f, 0f, W, H, p)
        val th = H - 2 * pad; val tw = th * 2.2f
        p.color = Color.parseColor("#0a0d20"); c.drawRect(pad, pad, pad + tw, pad + th, p)
        thumb?.let {
            val sc = min(tw / it.width, th / it.height); val bw = it.width * sc; val bh = it.height * sc
            c.drawBitmap(it, null, RectF(pad + (tw - bw) / 2, pad + th - bh, pad + (tw + bw) / 2, pad + th), np)
        }
        val tx = pad * 2 + tw
        if (count > 1) {
            PixelFont.draw(c, name, tx, H / 2 - 7 * ps, ps, if (on) UI.INK else UI.MUTE)
            PixelFont.draw(c, "$count THEMES", tx, H / 2 + 1.5f * ps, ps * 0.75f, UI.MUTE)
        } else PixelFont.draw(c, name, tx, H / 2 - 3.5f * ps, ps, if (on) UI.INK else UI.MUTE)
        p.style = Paint.Style.STROKE; p.strokeWidth = ps; p.color = if (on) UI.ACC else UI.LINE
        c.drawRect(ps / 2, ps / 2, W - ps / 2, H - ps / 2, p)
    }
}

/** Small live scene preview shown on the Themes and Widget tabs. */
class ScenePreview(ctx: Context) : View(ctx) {
    var off = 0
    private var frames: Array<Bitmap>? = null
    private var key = ""
    private val p = Paint().apply { isFilterBitmap = false }
    override fun onMeasure(w: Int, h: Int) {
        val W = MeasureSpec.getSize(w); setMeasuredDimension(W, (W / 2.1f).toInt())
    }
    override fun onDraw(c: Canvas) {
        val now = System.currentTimeMillis() + off * 60000L
        val s = Renderer.snap(now)
        val k = "${now / 60000L}|${Renderer.stateKey(context)}"
        if (frames == null || k != key) {
            frames = Array(3) { Renderer.scene(context, 800, 381, s, it, 800 * Renderer.radiusFrac(context)) }; key = k
        }
        c.drawBitmap(frames!![((System.currentTimeMillis() / 700) % 3).toInt()], null, Rect(0, 0, width, height), p)
    }
}
