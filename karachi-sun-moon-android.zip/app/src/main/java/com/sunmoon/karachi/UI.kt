package com.sunmoon.karachi

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.min

object UI {
    val BG = Color.parseColor("#0d1026"); val CARD = Color.parseColor("#171b3a")
    val LINE = Color.parseColor("#2a2f5c"); val INK = Color.parseColor("#f4ecd8")
    val MUTE = Color.parseColor("#9a9cc4"); val ACC = Color.parseColor("#ffb347")
}

/** Plain label in the app's pixel font. */
class PixelText(ctx: Context, var text: String, private val ps: Float, private val color: Int) : View(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize(PixelFont.width(text, ps).toInt() + 1, w), (8 * ps).toInt())
    }
    override fun onDraw(c: Canvas) { PixelFont.draw(c, text, 0f, ps / 2, ps, color) }
}

/** Boxed pixel button, same look as the Sunrise/Sunset tiles. Border turns orange when selected. */
class PixelButton(ctx: Context, var text: String) : View(ctx) {
    var on = false
        set(v) { field = v; invalidate() }
    private val ps = 2f * resources.displayMetrics.density
    private val p = Paint()
    init { isClickable = true }
    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize((PixelFont.width(text, ps) + 10 * ps).toInt(), w), (15 * ps).toInt())
    }
    override fun onDraw(c: Canvas) {
        val W = width.toFloat(); val H = height.toFloat()
        p.style = Paint.Style.FILL; p.color = UI.CARD; c.drawRect(0f, 0f, W, H, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = ps; p.color = if (on) UI.ACC else UI.LINE
        c.drawRect(ps / 2, ps / 2, W - ps / 2, H - ps / 2, p)
        PixelFont.draw(c, text, W / 2, (H - 7 * ps) / 2, ps, if (on) UI.INK else UI.MUTE, 2)
    }
}

/** One scenery in the Themes list: thumbnail, name and how many variants it has. */
class SceneryRow(ctx: Context, private val name: String, private val thumb: Bitmap?, private val count: Int) : View(ctx) {
    var on = false
        set(v) { field = v; invalidate() }
    private val ps = 2f * resources.displayMetrics.density
    private val p = Paint(); private val np = Paint().apply { isFilterBitmap = false }
    init { isClickable = true }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(resolveSize(0, w), (30 * ps).toInt()) }
    override fun onDraw(c: Canvas) {
        val W = width.toFloat(); val H = height.toFloat(); val pad = 3 * ps
        p.style = Paint.Style.FILL; p.color = UI.CARD; c.drawRect(0f, 0f, W, H, p)
        val th = H - 2 * pad; val tw = th * 2.2f
        p.color = Color.parseColor("#0a0d20"); c.drawRect(pad, pad, pad + tw, pad + th, p)
        thumb?.let {
            val sc = min(tw / it.width, th / it.height); val bw = it.width * sc; val bh = it.height * sc
            c.drawBitmap(it, null, RectF(pad + (tw - bw) / 2, pad + th - bh, pad + (tw + bw) / 2, pad + th), np)
        }
        val tx = pad * 2 + tw
        if (count > 1) {
            PixelFont.draw(c, name, tx, H / 2 - 7 * ps, ps, if (on) UI.INK else UI.MUTE)
            PixelFont.draw(c, "$count THEMES", tx, H / 2 + 1.5f * ps, ps * 0.75f, UI.MUTE)
        } else PixelFont.draw(c, name, tx, H / 2 - 3.5f * ps, ps, if (on) UI.INK else UI.MUTE)
        p.style = Paint.Style.STROKE; p.strokeWidth = ps; p.color = if (on) UI.ACC else UI.LINE
        c.drawRect(ps / 2, ps / 2, W - ps / 2, H - ps / 2, p)
    }
}
