package com.sunmoon.karachi

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.res.Configuration
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class SunMoonWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { draw(ctx, mgr, it) }
        schedule(ctx)
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, o: android.os.Bundle) {
        draw(ctx, mgr, id)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == TICK) {
            val mgr = AppWidgetManager.getInstance(ctx)
            mgr.getAppWidgetIds(ComponentName(ctx, SunMoonWidget::class.java)).forEach { draw(ctx, mgr, it) }
            schedule(ctx)
        }
    }

    override fun onDisabled(ctx: Context) {
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(tickIntent(ctx))
    }

    companion object {
        const val TICK = "com.sunmoon.karachi.TICK"

        private fun tickIntent(ctx: Context) = PendingIntent.getBroadcast(
            ctx, 0, Intent(ctx, SunMoonWidget::class.java).setAction(TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        fun schedule(ctx: Context) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(AlarmManager.RTC, System.currentTimeMillis() + 5 * 60000L, tickIntent(ctx))
        }

        fun refreshAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            mgr.getAppWidgetIds(ComponentName(ctx, SunMoonWidget::class.java)).forEach { draw(ctx, mgr, it) }
        }

        fun draw(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val o = mgr.getAppWidgetOptions(id)
            val land = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            // real widget size for the current orientation (portrait: min width x max height)
            val wd = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0)
            val hd = o.getInt(if (land) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0)
            val ratio = ((if (wd > 0) wd else 250).toFloat() / (if (hd > 0) hd else 110)).coerceIn(0.9f, 4.6f)
            val bw = 800; val bh = (bw / ratio).toInt().coerceIn(174, 890)
            val rv = RemoteViews(ctx.packageName, R.layout.widget)
            val snap = Renderer.snap(System.currentTimeMillis())
            val n = if (Renderer.needsFrames(ctx, snap)) 3 else 1
            val frames = List(n) { Renderer.scene(ctx, bw, bh, snap, it, bw * Renderer.radiusFrac(ctx)) }
            val ids = intArrayOf(R.id.f0, R.id.f1, R.id.f2)
            for (i in 0..2) rv.setImageViewBitmap(ids[i], frames[i % n])
            rv.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(
                ctx, 1, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            mgr.updateAppWidget(id, rv)
        }
    }
}
