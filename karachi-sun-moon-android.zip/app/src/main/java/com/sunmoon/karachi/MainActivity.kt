package com.sunmoon.karachi

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var view: AppView
    private val marks = ArrayList<() -> Unit>()
    private val MUTE = Color.parseColor("#9a9cc4"); private val ACC = Color.parseColor("#ffb347")
    private val tick = object : Runnable { override fun run() { view.invalidate(); h.postDelayed(this, 350) } }

    private fun prefs() = getSharedPreferences("sm", Context.MODE_PRIVATE)

    private fun changed() { view.invalidate(); SunMoonWidget.refreshAll(this); marks.forEach { it() } }

    /** A titled row of choices stored in prefs under [key]. */
    private fun options(title: String, hint: String?, names: List<String>, key: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, 24) }
        box.addView(TextView(this).apply { text = title; setTextColor(Color.WHITE); textSize = 15f; setPadding(48, 24, 48, 4) })
        if (hint != null) box.addView(TextView(this).apply { text = hint; setTextColor(MUTE); textSize = 12f; setPadding(48, 0, 48, 8) })
        val row = LinearLayout(this).apply { setPadding(40, 0, 40, 0) }
        val btns = ArrayList<Button>()
        fun mark() { val cur = prefs().getInt(key, if (key == "round") 1 else 0); btns.forEachIndexed { i, b -> b.text = (if (i == cur) "\u2713 " else "") + names[i] } }
        names.forEachIndexed { i, _ ->
            val b = Button(this).apply {
                isAllCaps = false; textSize = 12f
                setOnClickListener { prefs().edit().putInt(key, i).apply(); changed() }
            }
            btns.add(b); row.addView(b)
        }
        mark(); marks.add { mark() }
        box.addView(HorizontalScrollView(this).apply { addView(row) })
        return box
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        view = AppView(this)
        val sb = SeekBar(this).apply { max = 288; progress = 144; setPadding(48, 8, 48, 32) }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { view.off = (p - 144) * 5; view.invalidate() }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        view.onLive = { sb.progress = 144 }

        fun page(vararg v: View) = ScrollView(this).apply {
            addView(LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; v.forEach { addView(it) } })
        }
        val home = page(view, sb)
        val themes = page(
            options("Scenery", "Pick the place shown in the widget and app.", Renderer.SCENERY, "scenery"),
            options("Colours", "Colour mood for the scenery.", Renderer.THEMES.map { it.first }, "theme"))
        val widget = page(
            options("Corner roundness", null, Renderer.ROUNDS.map { it.first }, "round"),
            options("Animation", "Still = no twinkling stars or falling petals (saves battery).", listOf("Animated", "Still"), "anim"),
            options("Lights", "Lanterns and windows glow at night. Blink needs Animation on.", listOf("Steady", "Blink"), "lights"))
        val pages = listOf(home, themes, widget)

        val frame = FrameLayout(this)
        pages.forEach { frame.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        val bar = LinearLayout(this).apply { setBackgroundColor(Color.parseColor("#171b3a")) }
        val tabs = ArrayList<TextView>()
        fun show(i: Int) {
            pages.forEachIndexed { j, p -> p.visibility = if (i == j) View.VISIBLE else View.GONE }
            tabs.forEachIndexed { j, t -> t.setTextColor(if (i == j) ACC else MUTE) }
        }
        listOf("Home", "Themes", "Widget").forEachIndexed { i, n ->
            val t = TextView(this).apply { text = n; textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 32, 0, 32); setOnClickListener { show(i) } }
            tabs.add(t); bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        show(0)
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0d1026")); fitsSystemWindows = true
            addView(frame, LinearLayout.LayoutParams(-1, 0, 1f)); addView(bar)
        })
    }

    override fun onResume() { super.onResume(); tick.run() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
