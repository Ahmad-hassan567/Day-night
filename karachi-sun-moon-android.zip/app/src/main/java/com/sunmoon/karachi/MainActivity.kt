package com.sunmoon.karachi

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var view: AppView
    private val tick = object : Runnable { override fun run() { view.invalidate(); h.postDelayed(this, 1000) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        view = AppView(this)
        val sb = SeekBar(this).apply { max = 288; progress = 144; setPadding(48, 8, 48, 32) }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { view.off = (p - 144) * 5; view.invalidate() }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        view.onLive = { sb.progress = 144 }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(view); addView(sb) }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0d1026")); fitsSystemWindows = true; addView(col)
        })
    }

    override fun onResume() { super.onResume(); tick.run() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
