package com.sunmoon.karachi

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var view: AppView
    private val marks = ArrayList<() -> Unit>()
    private lateinit var variantBox: LinearLayout
    private lateinit var previewBox: LinearLayout

    private fun prefs() = getSharedPreferences("sm", Context.MODE_PRIVATE)
    private fun d() = resources.displayMetrics.density
    private fun dp(v: Float) = (v * d()).toInt()
    private val tick = object : Runnable { override fun run() { view.invalidate(); h.postDelayed(this, 350) } }

    private fun changed() { rebuildVariants(); rebuildPreview(); view.invalidate(); SunMoonWidget.refreshAll(this); marks.forEach { it() } }

    private fun title(t: String) = PixelText(this, t, 2f * d(), UI.INK).apply { setPadding(0, 0, 0, 0) }
    private fun hint(t: String) = TextView(this).apply { text = t; setTextColor(UI.MUTE); textSize = 12f }
    private fun lp(top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14f), top, dp(14f), bottom) }

    /** Titled row of PixelButtons stored in prefs under [key]. */
    private fun options(t: String, hintText: String?, names: List<String>, key: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(title(t.uppercase()), lp(dp(16f), dp(4f)))
        if (hintText != null) box.addView(hint(hintText), lp(0, dp(6f)))
        val row = LinearLayout(this).apply { setPadding(dp(14f), 0, dp(14f), 0) }
        val btns = ArrayList<PixelButton>()
        fun mark() { val cur = prefs().getInt(key, if (key == "round") 1 else 0); btns.forEachIndexed { i, b -> b.on = i == cur } }
        names.forEachIndexed { i, n ->
            val b = PixelButton(this, n.uppercase())
            b.setOnClickListener { prefs().edit().putInt(key, i).apply(); changed() }
            btns.add(b); row.addView(b, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8f) })
        }
        mark(); marks.add { mark() }
        box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        return box
    }

    private fun rebuildVariants() {
        variantBox.removeAllViews()
        val sc = Renderer.scenery(this)
        if (sc == 0) return
        val s = Registry.ALL[sc - 1]
        if (s.vs.size < 2) return
        variantBox.addView(title("VARIANT"), lp(dp(16f), dp(6f)))
        val row = LinearLayout(this).apply { setPadding(dp(14f), 0, dp(14f), 0) }
        val cur = Renderer.variantIndex(this)
        s.vs.forEachIndexed { i, _ ->
            val b = PixelButton(this, "THEME ${i + 1}"); b.on = i == cur
            b.setOnClickListener { prefs().edit().putInt("var_$sc", i).apply(); changed() }
            row.addView(b, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8f) })
        }
        variantBox.addView(row)
    }

    private fun rebuildPreview() {
        previewBox.removeAllViews()
        val snap = Renderer.snap(System.currentTimeMillis())
        val sizes = listOf("4X2" to 2.3f, "4X3" to 1.5f, "5X2" to 2.9f, "2X2" to 1.0f)
        sizes.forEach { (n, ratio) ->
            previewBox.addView(PixelText(this, n, 1.6f * d(), UI.MUTE), lp(dp(8f), dp(3f)))
            val w = 560; val bh = (w / ratio).toInt()
            val img = ImageView(this).apply {
                adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
                setImageBitmap(Renderer.scene(this@MainActivity, w, bh, snap, 0, w * Renderer.radiusFrac(this@MainActivity)))
            }
            previewBox.addView(img, LinearLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.9f * (if (ratio < 1.2f) 0.5f else 1f)).toInt(), -2)
                .apply { setMargins(dp(14f), 0, dp(14f), 0) })
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        view = AppView(this)
        val sb = SeekBar(this).apply { max = 288; progress = 144; setPadding(48, 8, 48, 32) }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { view.off = (p - 144) * 5; view.invalidate() }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        view.onLive = { sb.progress = 144 }

        fun page(vararg v: View) = ScrollView(this).apply {
            addView(LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(24f)); v.forEach { addView(it) } })
        }

        // Themes: variant row, scenery list, colours
        variantBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        list.addView(title("SCENERY"), lp(dp(16f), dp(6f)))
        val rows = ArrayList<SceneryRow>()
        Renderer.SCENERY.forEachIndexed { i, name ->
            val th: Bitmap? = if (i == 0) BitmapFactory.decodeResource(resources, R.drawable.shore_eve, BitmapFactory.Options().apply { inSampleSize = 4 })
                              else Renderer.thumb(this, Registry.ALL[i - 1].vs[0].key)
            val cnt = if (i == 0) 1 else Registry.ALL[i - 1].vs.size
            val r = SceneryRow(this, name.uppercase(), th, cnt)
            r.setOnClickListener { prefs().edit().putInt("scenery", i).apply(); changed() }
            rows.add(r); list.addView(r, lp(0, dp(8f)))
        }
        marks.add { val cur = Renderer.scenery(this); rows.forEachIndexed { i, r -> r.on = i == cur } }
        previewBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val home = page(view, sb)
        val themes = page(variantBox, list, options("Colours", "Colour mood for the scenery.", Renderer.THEMES.map { it.first }, "theme"))
        val widget = page(
            options("Corner roundness", null, Renderer.ROUNDS.map { it.first }, "round"),
            options("Animation", "Still = no twinkling stars or falling petals (saves battery).", listOf("Animated", "Still"), "anim"),
            options("Lights", "Windows and lanterns glow at night. Blink needs Animation on.", listOf("Steady", "Blink"), "lights"),
            title("SIZE PREVIEW").also { it.setPadding(dp(14f), dp(16f), 0, 0) }, previewBox)
        val pages = listOf(home, themes, widget)

        val frame = FrameLayout(this)
        pages.forEach { frame.addView(it, FrameLayout.LayoutParams(-1, -1)) }
        val bar = LinearLayout(this).apply { setBackgroundColor(UI.BG); setPadding(dp(10f), dp(8f), dp(10f), dp(10f)) }
        val tabs = ArrayList<PixelButton>()
        fun show(i: Int) {
            pages.forEachIndexed { j, p -> p.visibility = if (i == j) View.VISIBLE else View.GONE }
            tabs.forEachIndexed { j, t -> t.on = i == j }
        }
        listOf("HOME", "THEMES", "WIDGET").forEachIndexed { i, n ->
            val t = PixelButton(this, n); t.setOnClickListener { show(i) }
            tabs.add(t); bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(4f), 0, dp(4f), 0) })
        }
        show(0)
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(UI.BG); fitsSystemWindows = true
            addView(frame, LinearLayout.LayoutParams(-1, 0, 1f)); addView(bar)
        })
        rebuildVariants(); rebuildPreview(); marks.forEach { it() }
    }

    override fun onResume() { super.onResume(); tick.run() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
