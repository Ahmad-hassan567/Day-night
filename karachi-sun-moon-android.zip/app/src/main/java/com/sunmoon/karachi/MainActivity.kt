package com.sunmoon.karachi

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.Context
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.TextView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var view: AppView
    private val tick = object : Runnable { override fun run() { view.invalidate(); h.postDelayed(this, 350) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        view = AppView(this)
        val sb = SeekBar(this).apply { max = 288; progress = 144; setPadding(48, 8, 48, 32) }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { view.off = (p - 144) * 5; view.invalidate() }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        view.onLive = { sb.progress = 144 }
        val lbl = TextView(this).apply { text = "Shore colours (widget + app)"; setTextColor(Color.parseColor("#9a9cc4")); textSize = 13f; setPadding(48, 0, 48, 8) }
        val row = LinearLayout(this).apply { setPadding(40, 0, 40, 40) }
        val btns = ArrayList<Button>()
        fun mark() { val cur = Renderer.theme(this); btns.forEachIndexed { i, b -> b.text = (if (i == cur) "\u2713 " else "") + Renderer.THEMES[i].first } }
        Renderer.THEMES.forEachIndexed { i, t ->
            val bt = Button(this).apply {
                isAllCaps = false; textSize = 12f
                setOnClickListener {
                    getSharedPreferences("sm", Context.MODE_PRIVATE).edit().putInt("theme", i).apply()
                    mark(); view.invalidate(); SunMoonWidget.refreshAll(this@MainActivity)
                }
            }
            btns.add(bt); row.addView(bt)
        }
        mark()
        val lbl2 = TextView(this).apply { text = "Corner roundness (widget + app)"; setTextColor(Color.parseColor("#9a9cc4")); textSize = 13f; setPadding(48, 0, 48, 8) }
        val row2 = LinearLayout(this).apply { setPadding(40, 0, 40, 40) }
        val btns2 = ArrayList<Button>()
        fun mark2() { val cur = Renderer.round(this); btns2.forEachIndexed { i, b -> b.text = (if (i == cur) "\u2713 " else "") + Renderer.ROUNDS[i].first } }
        Renderer.ROUNDS.forEachIndexed { i, _ ->
            val bt = Button(this).apply {
                isAllCaps = false; textSize = 12f
                setOnClickListener {
                    getSharedPreferences("sm", Context.MODE_PRIVATE).edit().putInt("round", i).apply()
                    mark2(); view.invalidate(); SunMoonWidget.refreshAll(this@MainActivity)
                }
            }
            btns2.add(bt); row2.addView(bt)
        }
        mark2()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(view); addView(sb); addView(lbl); addView(HorizontalScrollView(this@MainActivity).apply { addView(row) }); addView(lbl2); addView(HorizontalScrollView(this@MainActivity).apply { addView(row2) }) }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0d1026")); fitsSystemWindows = true; addView(col)
        })
    }

    override fun onResume() { super.onResume(); tick.run() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
