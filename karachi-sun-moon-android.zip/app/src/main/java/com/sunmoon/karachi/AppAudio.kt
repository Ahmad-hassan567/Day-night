package com.sunmoon.karachi

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Handler
import android.os.Looper
import java.util.Calendar

/** Foreground-only audio. This class is owned exclusively by MainActivity; widgets never reference it. */
class AppAudio(private val context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("sm", Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
    private val soundPool = SoundPool.Builder().setMaxStreams(3).setAudioAttributes(
        AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
    private val sounds = HashMap<Int, Int>()
    private val players = LinkedHashMap<Int, MediaPlayer>()
    private val currentVolumes = HashMap<Int, Float>()
    private val activeSoundStreams = LinkedHashSet<Int>()
    private var loaded = false
    private var foreground = false
    private var focusHeld = false
    private var desired = emptyMap<Int, Float>()
    private var fadeStart = 0L
    private var fadeFrom = emptyMap<Int, Float>()
    private var fadeTo = emptyMap<Int, Float>()
    private var tickCallback: Runnable? = null
    private var lastUiSoundAt = 0L
    private var lastSliderProgress = -100
    private var lastSliderTickAt = 0L

    private val focusRequest by lazy {
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener { change ->
                if (change <= AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                    focusHeld = false
                    stopAmbience()
                } else if (change == AudioManager.AUDIOFOCUS_GAIN && foreground) {
                    focusHeld = true
                    refreshAmbience()
                }
            }.build()
    }

    fun startForeground() {
        foreground = true
        loadSounds()
        requestFocus()
        refreshAmbience()
        scheduleClockCheck()
    }

    fun stopForeground() {
        foreground = false
        tickCallback?.let { handler.removeCallbacks(it) }
        tickCallback = null
        stopAll()
        if (focusHeld) { audioManager.abandonAudioFocusRequest(focusRequest); focusHeld = false }
    }

    fun release() {
        stopForeground()
        players.values.toList().forEach { safeRelease(it) }
        players.clear()
        soundPool.release()
        loaded = false
    }

    fun playButton() = playUi(R.raw.ui_button_tap_pixel)

    fun playSliderTick(progress: Int) {
        if (!enabledUi()) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (kotlin.math.abs(progress - lastSliderProgress) < 4 || now - lastSliderTickAt < 65) return
        lastSliderProgress = progress; lastSliderTickAt = now
        val id = when { progress < 34 -> R.raw.ui_slider_tick_low; progress < 68 -> R.raw.ui_slider_tick_mid; else -> R.raw.ui_slider_tick_high }
        playUi(id)
    }

    fun playSliderRelease() { if (enabledUi()) playUi(R.raw.ui_slider_release_confirm) }

    fun updateVolumes() {
        if (!foreground) return
        if (!masterOn()) { stopAll(); return }
        if (!prefs.getBoolean("audio_ambience", true)) { stopAmbience(); return }
        refreshAmbience()
    }

    private fun enabledUi() = foreground && masterOn() && prefs.getBoolean("audio_ui", true)
    private fun masterOn() = prefs.getBoolean("audio_master", true)

    private fun loadSounds() {
        if (loaded) return
        val ids = listOf(R.raw.ui_button_tap_pixel, R.raw.ui_slider_tick_low, R.raw.ui_slider_tick_mid,
            R.raw.ui_slider_tick_high, R.raw.ui_slider_release_confirm)
        ids.forEach { sounds[it] = soundPool.load(app, it, 1) }
        loaded = true
    }

    private fun playUi(resource: Int) {
        if (!enabledUi()) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (resource == R.raw.ui_button_tap_pixel && now - lastUiSoundAt < 28) return
        lastUiSoundAt = now
        val soundId = sounds[resource] ?: return
        val volume = (prefs.getInt("audio_ui_volume", 75).coerceIn(0, 100) / 100f)
        val stream = soundPool.play(soundId, volume, volume, 1, 0, 1f)
        if (stream > 0) {
            activeSoundStreams.add(stream)
            if (activeSoundStreams.size > 32) activeSoundStreams.remove(activeSoundStreams.first())
        }
    }

    private fun requestFocus() {
        if (!masterOn() || focusHeld) return
        focusHeld = audioManager.requestAudioFocus(focusRequest) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun scheduleClockCheck() {
        tickCallback?.let { handler.removeCallbacks(it) }
        val r = object : Runnable {
            override fun run() {
                if (!foreground) return
                if (!masterOn()) stopAll() else if (prefs.getBoolean("audio_ambience", true)) refreshAmbience()
                handler.postDelayed(this, 30_000L)
            }
        }
        tickCallback = r
        handler.postDelayed(r, 30_000L)
    }

    private fun scheduleForLocalTime(): Map<Int, Float> {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val base = (prefs.getInt("audio_ambience_volume", 32).coerceIn(0, 100) / 100f)
        return when (hour) {
            in 5..8 -> mapOf(R.raw.ambience_morning_birds to base)
            in 9..15 -> mapOf(R.raw.ambience_day_cicadas to base)
            in 16..18 -> mapOf(R.raw.ambience_sunset_higurashi to base, R.raw.ambience_deep_night_crickets to base * .12f)
            in 19..21 -> mapOf(R.raw.ambience_night_suzumushi to base, R.raw.ambience_deep_night_crickets to base * .18f)
            else -> mapOf(R.raw.ambience_deep_night_crickets to base * .62f)
        }
    }

    private fun refreshAmbience() {
        if (!foreground || !masterOn() || !prefs.getBoolean("audio_ambience", true)) { stopAmbience(); return }
        requestFocus()
        val next = scheduleForLocalTime()
        if (next.keys == desired.keys && next.all { (k, v) -> kotlin.math.abs((desired[k] ?: 0f) - v) < .001f }) return
        beginCrossfade(next)
    }

    private fun beginCrossfade(next: Map<Int, Float>) {
        val from = players.keys.associateWith { currentVolumes[it] ?: 0f }
        next.keys.forEach { id ->
            if (!players.containsKey(id)) {
                val p = MediaPlayer.create(app, id) ?: return@forEach
                p.setAudioAttributes(attrs); p.isLooping = true; p.setVolume(0f, 0f)
                runCatching { p.start() }
                players[id] = p
            }
        }
        desired = next
        fadeStart = android.os.SystemClock.elapsedRealtime()
        fadeFrom = from
        fadeTo = next
        handler.removeCallbacks(fadeRunnable)
        handler.post(fadeRunnable)
    }

    private val fadeRunnable = object : Runnable {
        override fun run() {
            if (!foreground) return
            val fraction = ((android.os.SystemClock.elapsedRealtime() - fadeStart) / 3000f).coerceIn(0f, 1f)
            players.toMap().forEach { (id, player) ->
                val a = fadeFrom[id] ?: 0f
                val b = fadeTo[id] ?: 0f
                val v = (a + (b - a) * fraction).coerceIn(0f, 1f)
                runCatching { player.setVolume(v, v) }; currentVolumes[id] = v
            }
            if (fraction < 1f) handler.postDelayed(this, 45L)
            else {
                players.toMap().forEach { (id, player) -> if (!fadeTo.containsKey(id)) { safeRelease(player); players.remove(id); currentVolumes.remove(id) } }
            }
        }
    }

    private fun stopAmbience() {
        desired = emptyMap(); fadeTo = emptyMap()
        if (players.isEmpty()) return
        beginCrossfade(emptyMap())
    }

    private fun stopAll() {
        handler.removeCallbacks(fadeRunnable)
        players.values.toList().forEach { safeRelease(it) }
        players.clear(); currentVolumes.clear(); desired = emptyMap(); fadeFrom = emptyMap(); fadeTo = emptyMap()
        activeSoundStreams.toList().forEach { soundPool.stop(it) }; activeSoundStreams.clear()
    }

    private fun safeRelease(player: MediaPlayer) { runCatching { if (player.isPlaying) player.stop() }; runCatching { player.release() } }
}
