package com.sunmoon.karachi

/** Generated scenery list. V = image key, horizon, sun/moon path start/end (x), average brightness, height/width ratio, petal box. */
object Registry {
    class V(val key: String, val hz: Float, val x0: Float, val x1: Float, val lum: Float, val r: Float, val petals: FloatArray?)
    class S(val name: String, val vs: List<V>)
    val ALL = listOf(
        S("22nd Century", listOf(V("22ndcentury1", 0.588f, 0.29f, 0.76f, 175.1f, 0.260f, null), V("22ndcentury2", 0.696f, 0.30f, 0.74f, 130.1f, 0.332f, null))),
        S("Among Us", listOf(V("amongus", 0.609f, 0.28f, 0.62f, 107.0f, 0.281f, null))),
        S("Cafe", listOf(V("cafe1", 0.885f, 0.18f, 0.82f, 76.4f, 0.383f, null), V("cafe2", 0.906f, 0.32f, 0.64f, 76.2f, 0.297f, null))),
        S("Clash", listOf(V("clash", 0.687f, 0.18f, 0.82f, 101.4f, 0.310f, null))),
        S("Clifton", listOf(V("clifton", 0.713f, 0.31f, 0.83f, 148.7f, 0.338f, null))),
        S("Dark Base", listOf(V("darkbase1", 0.727f, 0.18f, 0.82f, 34.3f, 0.362f, null), V("darkbase2", 0.767f, 0.33f, 0.75f, 29.2f, 0.416f, null))),
        S("Doraemon", listOf(V("doraemon1", 0.729f, 0.18f, 0.82f, 117.5f, 0.317f, null), V("doraemon2", 0.652f, 0.18f, 0.82f, 116.6f, 0.302f, null))),
        S("Dragon Ball", listOf(V("dragonball", 0.753f, 0.18f, 0.82f, 116.7f, 0.339f, null))),
        S("Gas Station", listOf(V("gasstation1", 0.658f, 0.41f, 0.79f, 93.6f, 0.319f, null), V("gasstation2", 0.624f, 0.42f, 0.81f, 82.6f, 0.335f, null), V("gasstation3", 0.622f, 0.39f, 0.79f, 102.8f, 0.262f, null))),
        S("Grove Street", listOf(V("grovestreet", 0.607f, 0.18f, 0.82f, 106.7f, 0.305f, null))),
        S("Industrial Base", listOf(V("industrialbase", 0.666f, 0.30f, 0.67f, 92.5f, 0.311f, null))),
        S("Japanese House", listOf(V("japanesehouse1", 0.581f, 0.18f, 0.82f, 92.6f, 0.334f, floatArrayOf(0.735f, 0.993f, 0.368f)), V("japanesehouse2", 0.766f, 0.39f, 0.71f, 79.7f, 0.329f, floatArrayOf(0.628f, 0.990f, 0.517f)), V("japanesehouse3", 0.758f, 0.30f, 0.74f, 78.7f, 0.310f, floatArrayOf(0.600f, 0.991f, 0.568f)))),
        S("Lighthouse", listOf(V("lighthouse", 0.774f, 0.29f, 0.86f, 85.2f, 0.416f, null))),
        S("Mario", listOf(V("mario", 0.718f, 0.18f, 0.82f, 98.2f, 0.340f, null))),
        S("Mars", listOf(V("mars", 0.601f, 0.33f, 0.77f, 113.8f, 0.306f, null))),
        S("Military Camp", listOf(V("militarycamp", 0.650f, 0.18f, 0.82f, 73.2f, 0.329f, null))),
        S("Minecraft", listOf(V("minecraft", 0.713f, 0.31f, 0.78f, 96.2f, 0.369f, null))),
        S("Naruto", listOf(V("naruto", 0.660f, 0.18f, 0.82f, 104.7f, 0.324f, null))),
        S("Neon Shop", listOf(V("neonshop1", 0.647f, 0.28f, 0.78f, 79.5f, 0.320f, null), V("neonshop2", 0.822f, 0.46f, 0.79f, 88.4f, 0.360f, null), V("neonshop3", 0.468f, 0.18f, 0.82f, 83.0f, 0.365f, null))),
        S("Pokemon", listOf(V("pokemon", 0.659f, 0.18f, 0.82f, 119.7f, 0.255f, null))),
        S("Ramen", listOf(V("ramen1", 0.686f, 0.33f, 0.77f, 92.5f, 0.344f, null), V("ramen2", 0.590f, 0.34f, 0.81f, 104.1f, 0.273f, null))),
        S("Saloon", listOf(V("saloon", 0.877f, 0.18f, 0.82f, 91.4f, 0.284f, null))),
        S("Sci Fi Base", listOf(V("scifibase", 0.749f, 0.28f, 0.71f, 69.3f, 0.407f, null))),
        S("Snow House", listOf(V("snowhouse1", 0.751f, 0.35f, 0.74f, 95.4f, 0.410f, null), V("snowhouse2", 0.728f, 0.31f, 0.69f, 95.9f, 0.390f, null))),
        S("Sonic", listOf(V("sonic", 0.706f, 0.26f, 0.76f, 95.2f, 0.347f, null))),
        S("Space Station", listOf(V("spacestation1", 0.837f, 0.18f, 0.82f, 83.9f, 0.398f, null), V("spacestation2", 0.730f, 0.30f, 0.74f, 99.7f, 0.403f, null), V("spacestation3", 0.764f, 0.18f, 0.82f, 103.6f, 0.390f, null))),
        S("Voyager", listOf(V("voyager", 0.739f, 0.35f, 0.75f, 105.0f, 0.372f, null)))
    )
}
