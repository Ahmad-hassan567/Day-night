package com.sunmoon.karachi

import android.content.Context

/** Per-scene data for shadows/reflections, read from assets/scenes/profiles.txt.
 *  oh = height of everything rising above the horizon line, sampled across the width (fraction of image height).
 *  water = [x start, x end, bottom] of a water band, or null. */
object Profiles {
    class P(val oh: FloatArray, val water: FloatArray?)
    private var map: HashMap<String, P>? = null

    @Synchronized
    fun get(ctx: Context, key: String): P? {
        if (map == null) {
            val m = HashMap<String, P>()
            try {
                ctx.assets.open("scenes/profiles.txt").bufferedReader().useLines { ls ->
                    ls.forEach { l ->
                        val t = l.split("|")
                        if (t.size >= 3) {
                            val w = if (t[1] == "-") null else t[1].split(",").map { it.toFloat() }.toFloatArray()
                            m[t[0]] = P(t[2].trim().split(" ").map { it.toFloat() }.toFloatArray(), w)
                        }
                    }
                }
            } catch (e: Exception) { }
            map = m
        }
        return map!![key]
    }
}
