package com.sunmoon.karachi

import android.content.Context

/** Per-scene data read from assets/scenes/profiles.txt.
 *  oh    = height of everything rising above the horizon line, sampled across the width (fraction of image height).
 *  water = [x start, x end, top, bottom] of the water band, or null.
 *  beams = street-light beams [x centre, y top, y bottom, width top, width bottom] drawn by code at night. */
object Profiles {
    class P(val oh: FloatArray, val water: FloatArray?, val beams: List<FloatArray>)
    private var map: HashMap<String, P>? = null

    @Synchronized
    fun get(ctx: Context, key: String): P? {
        if (map == null) {
            val m = HashMap<String, P>()
            try {
                ctx.assets.open("scenes/profiles.txt").bufferedReader().useLines { ls ->
                    ls.forEach { l ->
                        val t = l.split("|")
                        if (t.size >= 3) {
                            val w = if (t[1] == "-") null else t[1].split(",").map { it.toFloat() }.toFloatArray()
                            val bm = if (t.size < 4 || t[3].trim() == "-") emptyList()
                                     else t[3].trim().split(";").map { b -> b.split(",").map { it.toFloat() }.toFloatArray() }
                            m[t[0]] = P(t[2].trim().split(" ").map { it.toFloat() }.toFloatArray(), w, bm)
                        }
                    }
                }
            } catch (e: Exception) { }
            map = m
        }
        return map!![key]
    }
}
