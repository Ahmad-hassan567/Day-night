package com.sunmoon.karachi

import android.graphics.Canvas
import android.graphics.Paint

/** Self-contained 5x7 pixel font, drawn pixel by pixel (no font file needed). */
object PixelFont {
    private val G = HashMap<Char, IntArray>()
    private fun g(c: Char, s: String) { G[c] = s.split(",").map { it.toInt(16) }.toIntArray() }
    init {
        g('0', "0E,11,13,15,19,11,0E"); g('1', "04,0C,04,04,04,04,0E"); g('2', "0E,11,01,02,04,08,1F")
        g('3', "1F,02,04,02,01,11,0E"); g('4', "02,06,0A,12,1F,02,02"); g('5', "1F,10,1E,01,01,11,0E")
        g('6', "06,08,10,1E,11,11,0E"); g('7', "1F,01,02,04,08,08,08"); g('8', "0E,11,11,0E,11,11,0E")
        g('9', "0E,11,11,0F,01,02,0C")
        g('A', "0E,11,11,1F,11,11,11"); g('B', "1E,11,11,1E,11,11,1E"); g('C', "0E,11,10,10,10,11,0E")
        g('D', "1C,12,11,11,11,12,1C"); g('E', "1F,10,10,1E,10,10,1F"); g('F', "1F,10,10,1E,10,10,10")
        g('G', "0E,11,10,17,11,11,0F"); g('H', "11,11,11,1F,11,11,11"); g('I', "0E,04,04,04,04,04,0E")
        g('J', "07,02,02,02,02,12,0C"); g('K', "11,12,14,18,14,12,11"); g('L', "10,10,10,10,10,10,1F")
        g('M', "11,1B,15,15,11,11,11"); g('N', "11,11,19,15,13,11,11"); g('O', "0E,11,11,11,11,11,0E")
        g('P', "1E,11,11,1E,10,10,10"); g('Q', "0E,11,11,11,15,12,0D"); g('R', "1E,11,11,1E,14,12,11")
        g('S', "0F,10,10,0E,01,01,1E"); g('T', "1F,04,04,04,04,04,04"); g('U', "11,11,11,11,11,11,0E")
        g('V', "11,11,11,11,11,0A,04"); g('W', "11,11,11,15,15,15,0A"); g('X', "11,11,0A,04,0A,11,11")
        g('Y', "11,11,0A,04,04,04,04"); g('Z', "1F,01,02,04,08,10,1F")
        g(':', "00,04,00,00,00,04,00"); g('.', "00,00,00,00,00,0C,0C"); g('-', "00,00,00,1F,00,00,00")
        g('+', "00,04,04,1F,04,04,00"); g('/', "01,01,02,04,08,10,10"); g('(', "02,04,08,08,08,04,02")
        g(')', "08,04,02,02,02,04,08"); g(' ', "00,00,00,00,00,00,00")
    }

    fun width(t: String, ps: Float) = if (t.isEmpty()) 0f else (t.length * 6 - 1) * ps

    /** align: 0 left, 1 right, 2 center. (x, y) = top edge of text. */
    fun draw(c: Canvas, t: String, x: Float, y: Float, ps: Float, color: Int, align: Int = 0, shadow: Int = 0) {
        val p = Paint().apply { isAntiAlias = false }
        val x0 = when (align) { 1 -> x - width(t, ps); 2 -> x - width(t, ps) / 2; else -> x }
        for (pass in 0..(if (shadow != 0) 1 else 0)) {
            p.color = if (shadow != 0 && pass == 0) shadow else color
            val o = if (shadow != 0 && pass == 0) ps * 0.8f else 0f
            var cx = x0 + o
            for (ch in t) {
                val rows = G[ch.uppercaseChar()] ?: G[' ']!!
                for (r in 0 until 7) for (b in 0 until 5) if (rows[r] and (1 shl (4 - b)) != 0)
                    c.drawRect(cx + b * ps, y + o + r * ps, cx + (b + 1) * ps, y + o + (r + 1) * ps, p)
                cx += 6 * ps
            }
        }
    }
}
