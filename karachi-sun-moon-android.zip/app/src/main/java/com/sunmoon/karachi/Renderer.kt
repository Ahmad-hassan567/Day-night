package com.sunmoon.karachi

import android.content.Context
import android.graphics.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

object Renderer {
    private const val HZ = 0.755f
    val TZ: TimeZone = TimeZone.getTimeZone("Asia/Karachi")
    private val K = arrayOf(
        Triple(-18.0, "#050816", "#0c1440"), Triple(-8.0, "#14184a", "#3a2a6a"),
        Triple(-2.0, "#3b2d7a", "#e0627a"), Triple(3.0, "#5a6fc0", "#ffa05a"),
        Triple(10.0, "#4a9fe0", "#ffd08a"), Triple(25.0, "#2f8fe6", "#9fd8f5"),
        Triple(90.0, "#1f7fe0", "#8fd3f7")
    )
    private val cache = HashMap<Int, Bitmap>()

    fun fmt(t: Long): String = SimpleDateFormat("h:mm a", Locale.US).apply { timeZone = TZ }.format(Date(t))

    /** Everything the app needs to know about one moment in time. */
    class Snap(val now: Long) {
        val sun = Astro.body(now, false)
        val moon = Astro.body(now, true)
        val alt = Astro.alt(now, false)
        val am = Calendar.getInstance(TZ).apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY) < 12
        val night = alt < -3
        val eve = !night && !am && alt <= 10
        val phase = if (night) "Raat" else if (am) "Subah" else if (alt > 10) "Dopahar" else "Shaam"
        fun pick(up: Boolean, moonBody: Boolean): String {
            val d = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = TZ }
            val b = if (moonBody) moon else sun
            return b.ev.firstOrNull { it.up == up && d.format(Date(it.t)) == d.format(Date(now)) }?.let { fmt(it.t) } ?: "--"
        }
        /** (tile index 0..3 = sunrise, sunset, moonrise, moonset, time, countdown text) */
        fun next(): Triple<Int, Long, String>? {
            val c = listOfNotNull(
                sun.next?.let { Triple(if (it.up) 0 else 1, it.t, if (it.up) "Sunrise" else "Sunset") },
                moon.next?.let { Triple(if (it.up) 2 else 3, it.t, if (it.up) "Moonrise" else "Moonset") })
            return c.minByOrNull { it.second }
        }
    }

    fun snap(now: Long) = Snap(now)

    private fun mix(a: Int, b: Int, k: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt())

    private fun sky(a0: Double): Pair<Int, Int> {
        val a = max(-18.0, a0)
        var i = 1
        while (i < K.size - 1 && a > K[i].first) i++
        val x = K[i - 1]; val y = K[i]
        val k = ((a - x.first) / (y.first - x.first)).coerceIn(0.0, 1.0).toFloat()
        return Pair(mix(Color.parseColor(x.second), Color.parseColor(y.second), k),
            mix(Color.parseColor(x.third), Color.parseColor(y.third), k))
    }

    private fun bmp(ctx: Context, id: Int): Bitmap = cache.getOrPut(id) {
        BitmapFactory.decodeResource(ctx.resources, id, BitmapFactory.Options().apply { inScaled = false })
    }

    /** Scene only: sky, stars, sun, moon, shore. No text. */
    fun scene(ctx: Context, W: Int, H: Int, s: Snap): Bitmap {
        val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val np = Paint().apply { isFilterBitmap = false }
        val a = s.alt

        val (top, bot) = sky(a)
        p.shader = LinearGradient(0f, 0f, 0f, H.toFloat(), top, bot, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p); p.shader = null

        val shoreId = if (s.night) R.drawable.shore_night else if (s.eve) R.drawable.shore_eve else R.drawable.shore_day
        val shore = bmp(ctx, shoreId)
        val shoreH = W.toFloat() * shore.height / shore.width
        val hor = H - shoreH * (1 - HZ)

        val so = ((-a - 2) / 8).coerceIn(0.0, 1.0)
        if (so > 0 && !(s.moon.p != null && a > 0)) {
            val sp = Paint().apply { alpha = (so * 255).toInt() }
            val ids = intArrayOf(R.drawable.star0, R.drawable.star1, R.drawable.star2, R.drawable.star3, R.drawable.star4, R.drawable.star5)
            for (i in 0 until 14) {
                val st = bmp(ctx, ids[i % 6])
                val w = W * (if (i % 3 == 0) 0.04f else 0.028f); val h = w * st.height / st.width
                val x = W * (0.07f + ((i * 37) % 86) / 100f); val y = H * (0.05f + ((i * 23) % 38) / 100f * 0.8f)
                c.drawBitmap(st, null, RectF(x, y, x + w, y + h), sp)
            }
        }

        fun place(b: Bitmap, w: Float, pr: Double?, glow: Int) {
            if (pr == null) return
            val h = w * b.height / b.width
            val x = W * (0.14f + 0.82f * pr.toFloat())
            val y = hor + h / 2 - sin(PI * pr).toFloat() * hor * 0.8f
            val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(x, y, w * 1.1f, glow, Color.TRANSPARENT, Shader.TileMode.CLAMP) }
            c.drawCircle(x, y, w * 1.1f, gp)
            c.drawBitmap(b, null, RectF(x - w / 2, y - h / 2, x + w / 2, y + h / 2), np)
        }
        place(bmp(ctx, R.drawable.moon), W * 0.075f, s.moon.p, Color.argb(90, 220, 210, 255))
        place(bmp(ctx, R.drawable.sun), W * 0.105f, s.sun.p, Color.argb(110, 255, 200, 70))

        c.drawBitmap(shore, null, RectF(0f, H - shoreH, W.toFloat(), H.toFloat()), np)
        return out
    }
}
