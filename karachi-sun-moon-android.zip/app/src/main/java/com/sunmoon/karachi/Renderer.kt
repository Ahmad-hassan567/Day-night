package com.sunmoon.karachi

import android.content.Context
import android.graphics.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

object Renderer {
    private const val HZ = 0.755f
    val TZ: TimeZone = TimeZone.getTimeZone("Asia/Karachi")
    private val K = arrayOf(
        Triple(-18.0, "#050816", "#0c1440"), Triple(-8.0, "#14184a", "#3a2a6a"),
        Triple(-2.0, "#3b2d7a", "#e0627a"), Triple(3.0, "#5a6fc0", "#ffa05a"),
        Triple(10.0, "#4a9fe0", "#ffd08a"), Triple(25.0, "#2f8fe6", "#9fd8f5"),
        Triple(90.0, "#1f7fe0", "#8fd3f7")
    )
    private val cache = HashMap<Int, Bitmap>()

    fun fmt(t: Long): String = SimpleDateFormat("h:mm a", Locale.US).apply { timeZone = TZ }.format(Date(t))

    /** Everything the app needs to know about one moment in time. */
    class Snap(val now: Long) {
        val sun = Astro.body(now, false)
        val moon = Astro.body(now, true)
        val alt = Astro.alt(now, false)
        val am = Calendar.getInstance(TZ).apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY) < 12
        val night = alt < -3
        val eve = !night && !am && alt <= 10
        val phase = if (night) "NIGHT" else if (am) "MORNING" else if (alt > 10) "AFTERNOON" else "EVENING"
        fun pick(up: Boolean, moonBody: Boolean): String {
            val d = SimpleDateFormat("yyyyMMdd", Locale.US).apply { timeZone = TZ }
            val b = if (moonBody) moon else sun
            return b.ev.firstOrNull { it.up == up && d.format(Date(it.t)) == d.format(Date(now)) }?.let { fmt(it.t) } ?: "--"
        }
        /** (tile index 0..3 = sunrise, sunset, moonrise, moonset, time, countdown text) */
        fun next(): Triple<Int, Long, String>? {
            val c = listOfNotNull(
                sun.next?.let { Triple(if (it.up) 0 else 1, it.t, if (it.up) "Sunrise" else "Sunset") })
            return c.minByOrNull { it.second }
        }
    }

    fun snap(now: Long) = Snap(now)

    private fun mix(a: Int, b: Int, k: Float) = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt())

    private fun sky(a0: Double): Pair<Int, Int> {
        val a = max(-18.0, a0)
        var i = 1
        while (i < K.size - 1 && a > K[i].first) i++
        val x = K[i - 1]; val y = K[i]
        val k = ((a - x.first) / (y.first - x.first)).coerceIn(0.0, 1.0).toFloat()
        return Pair(mix(Color.parseColor(x.second), Color.parseColor(y.second), k),
            mix(Color.parseColor(x.third), Color.parseColor(y.third), k))
    }

    private fun bmp(ctx: Context, id: Int): Bitmap = cache.getOrPut(id) {
        BitmapFactory.decodeResource(ctx.resources, id, BitmapFactory.Options().apply { inScaled = false })
    }

    /** Scene only: sky, stars, sun, moon, shore. No text. */
    /** name to (hue degrees, saturation, brightness) applied to the shore image only */
    val THEMES = listOf(
        "Original" to floatArrayOf(0f, 1f, 1f), "Pastel" to floatArrayOf(0f, .55f, 1.1f),
        "Vivid" to floatArrayOf(0f, 1.4f, 1f), "Sakura" to floatArrayOf(240f, 1f, 1f),
        "Vaporwave" to floatArrayOf(90f, 1f, 1f))

    /** corner radius as a fraction of widget/scene width */
    val ROUNDS = listOf("Square" to 0f, "Slight" to 0.045f, "Medium" to 0.08f, "Round" to 0.13f)

    fun round(ctx: Context) = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt("round", 1).coerceIn(0, ROUNDS.size - 1)
    fun radiusFrac(ctx: Context) = ROUNDS[round(ctx)].second

    fun theme(ctx: Context) = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt("theme", 0).coerceIn(0, THEMES.size - 1)

    private fun themeFilter(i: Int): ColorFilter? = if (i == 0) null else ColorMatrixColorFilter(themeMatrix(i))

    private fun themeMatrix(i: Int): ColorMatrix {
        if (i == 0) return ColorMatrix()
        val (h, sat, br) = THEMES[i].second.let { Triple(it[0], it[1], it[2]) }
        val a = cos(h * PI / 180).toFloat(); val b = sin(h * PI / 180).toFloat()
        val cm = ColorMatrix(); cm.setSaturation(sat)
        cm.postConcat(ColorMatrix(floatArrayOf(
            .213f + .787f * a - .213f * b, .715f - .715f * a - .715f * b, .072f - .072f * a + .928f * b, 0f, 0f,
            .213f - .213f * a + .143f * b, .715f + .285f * a + .140f * b, .072f - .072f * a - .283f * b, 0f, 0f,
            .213f - .213f * a - .787f * b, .715f - .715f * a + .715f * b, .072f + .928f * a + .072f * b, 0f, 0f,
            0f, 0f, 0f, 1f, 0f)))
        cm.postConcat(ColorMatrix(floatArrayOf(br, 0f, 0f, 0f, 0f, 0f, br, 0f, 0f, 0f, 0f, 0f, br, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
        return cm
    }

    private fun pref(ctx: Context, k: String) = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt(k, 0)
    fun animated(ctx: Context) = pref(ctx, "anim") == 0
    fun blink(ctx: Context) = pref(ctx, "lights") == 1 && animated(ctx)
    fun needsFrames(ctx: Context, s: Snap) = animated(ctx) && (starsOn(s) || scenery(ctx) == 1)

    /** Soft bloom of lit windows/lanterns, built once from the image's own bright warm pixels (so colours match). */
    private fun glowBmp(ctx: Context): Bitmap = cache.getOrPut(-1) {
        val src = bmp(ctx, R.drawable.shore_jp); val w = src.width; val h = src.height
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        val hsv = FloatArray(3)
        for (y in 0 until h) for (x in 0 until w) {
            val c0 = px[y * w + x]; var keep = false
            if (Color.alpha(c0) > 200 && y < h * 0.74 && x < w * 0.40) {
                Color.colorToHSV(c0, hsv); keep = hsv[2] > 0.72f && hsv[1] > 0.35f && hsv[0] in 10f..55f
            }
            px[y * w + x] = if (keep) (c0 or 0xFF000000.toInt()) else 0
        }
        val emi = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        val small = Bitmap.createScaledBitmap(emi, w / 8, h / 8, true)
        Bitmap.createScaledBitmap(small, w / 2, h / 2, true)
    }

    val SCENERY = listOf("Beach", "Japan")
    fun scenery(ctx: Context) = ctx.getSharedPreferences("sm", Context.MODE_PRIVATE).getInt("scenery", 0).coerceIn(0, SCENERY.size - 1)

    /** Japan scene is one evening image; recolour it by sun altitude (day = brighter/cooler, night = dark/blue). */
    private fun phaseMatrix(a: Double): ColorMatrix {
        val n = ((3 - a) / 8).coerceIn(0.0, 1.0).toFloat(); val d = ((a - 3) / 10).coerceIn(0.0, 1.0).toFloat()
        val r = 1f + d * 0.10f - n * 0.58f; val g = 1f + d * 0.22f - n * 0.50f; val b = 1f + d * 0.30f - n * 0.15f
        val cm = ColorMatrix(); cm.setSaturation(1f - n * 0.15f - d * 0.1f)
        cm.postConcat(ColorMatrix(floatArrayOf(r, 0f, 0f, 0f, 0f, 0f, g, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
        return cm
    }

    // lantern centres in the Japan image (x, y as fractions of image width/height)
    private val LANTERNS = arrayOf(0.029f to 0.299f, 0.129f to 0.282f, 0.252f to 0.316f, 0.084f to 0.633f,
        0.157f to 0.625f, 0.285f to 0.635f, 0.329f to 0.633f)

    fun starsOn(s: Snap) = ((-s.alt - 2) / 8) > 0 && !(s.moon.p != null && s.alt > 0)

    fun scene(ctx: Context, W: Int, H: Int, s: Snap, frame0: Int = 0, radius: Float = 0f): Bitmap {
        val frame = if (animated(ctx)) frame0 else 0
        val blink = blink(ctx)
        val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val np = Paint().apply { isFilterBitmap = false }
        val a = s.alt

        val (top, bot) = sky(a)
        p.shader = LinearGradient(0f, 0f, 0f, H.toFloat(), top, bot, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p); p.shader = null

        val jp = scenery(ctx) == 1
        val hz = if (jp) 0.764f else HZ
        val shoreId = if (jp) R.drawable.shore_jp else if (s.night) R.drawable.shore_night else if (s.eve) R.drawable.shore_eve else R.drawable.shore_day
        val shore = bmp(ctx, shoreId)
        val shoreH = W.toFloat() * shore.height / shore.width
        val hor = H - shoreH * (1 - hz)

        val so = ((-a - 2) / 8).coerceIn(0.0, 1.0)
        if (so > 0 && !(s.moon.p != null && a > 0)) {
            val sp = Paint().apply { alpha = (so * 255).toInt() }
            val ids = intArrayOf(R.drawable.star0, R.drawable.star1, R.drawable.star2, R.drawable.star3, R.drawable.star4, R.drawable.star5)
            for (i in 0 until 14) {
                val st = bmp(ctx, ids[i % 6])
                val w = W * (if (i % 3 == 0) 0.04f else 0.028f); val h = w * st.height / st.width
                val x = W * (0.07f + ((i * 37) % 86) / 100f); val y = H * (0.05f + ((i * 23) % 38) / 100f * 0.8f)
                val k = floatArrayOf(1f, 0.7f, 0.4f)[(i + frame) % 3]
                val cx = x + w / 2; val cy = y + h / 2
                sp.alpha = (so * (0.45 + 0.55 * k) * 255).toInt()
                c.drawBitmap(st, null, RectF(cx - w * k / 2, cy - h * k / 2, cx + w * k / 2, cy + h * k / 2), sp)
            }
        }

        fun place(b: Bitmap, w: Float, pr: Double?, glow: Int) {
            if (pr == null) return
            val h = w * b.height / b.width
            val x = W * ((if (jp) 0.2f else 0.14f) + ((if (jp) 0.78f else 0.96f) - (if (jp) 0.2f else 0.14f)) * pr.toFloat())
            val y = hor + h / 2 - sin(PI * pr).toFloat() * hor * 0.8f
            val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = RadialGradient(x, y, w * 1.1f, glow, Color.TRANSPARENT, Shader.TileMode.CLAMP) }
            c.drawCircle(x, y, w * 1.1f, gp)
            c.drawBitmap(b, null, RectF(x - w / 2, y - h / 2, x + w / 2, y + h / 2), np)
        }
        place(bmp(ctx, R.drawable.moon), W * 0.075f, s.moon.p, Color.argb(90, 220, 210, 255))
        place(bmp(ctx, R.drawable.sun), W * 0.105f, s.sun.p, Color.argb(110, 255, 200, 70))

        val shp = Paint().apply { isFilterBitmap = false
            colorFilter = if (jp) ColorMatrixColorFilter(ColorMatrix(themeMatrix(theme(ctx))).apply { postConcat(phaseMatrix(a)) }) else themeFilter(theme(ctx)) }
        c.drawBitmap(shore, null, RectF(0f, H - shoreH, W.toFloat(), H.toFloat()), shp)
        if (jp) {
            val top0 = H - shoreH
            val n = ((3 - a) / 8).coerceIn(0.0, 1.0).toFloat()
            if (n > 0f) {
                val gp = Paint().apply { isFilterBitmap = true; xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
                    alpha = (n * (if (blink) floatArrayOf(1f, .75f, .9f)[frame % 3] else 1f) * 210).toInt() }
                c.drawBitmap(glowBmp(ctx), null, RectF(0f, top0, W.toFloat(), H.toFloat()), gp)
            }
            if (n > 0f) LANTERNS.forEachIndexed { i, (lx, ly) ->
                val cx = W * lx; val cy = top0 + shoreH * ly; val rad = W * 0.04f
                val al = (n * (0.5f + 0.18f * (if (blink) (i + frame) % 3 else 1)) * 255).toInt()
                val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(cx, cy, rad, Color.argb(al, 255, 170, 60), Color.TRANSPARENT, Shader.TileMode.CLAMP) }
                c.drawCircle(cx, cy, rad, gp)
            }
            // falling sakura petals (3 frames loop seamlessly)
            val step = H * 0.035f; val per = step * 3
            val pTop = top0 + shoreH * 0.45f; val pBot = top0 + shoreH * 0.93f; val ps = W * 0.0065f
            val pp = Paint().apply { colorFilter = shp.colorFilter }
            if (animated(ctx)) for (lane in 0 until 7) {
                val bx = W * (0.82f + 0.15f * ((lane * 37) % 7) / 7f)
                val y0 = pTop + ((lane * 0.37f) % 1f) * per + frame * step
                for (k in 0..9) {
                    val y = y0 + k * per
                    if (y >= pBot) break
                    val x = bx + sin(lane + y / (H * 0.05f)) * W * 0.012f
                    pp.color = if ((lane + k) % 2 == 0) Color.rgb(255, 158, 203) else Color.rgb(255, 205, 225)
                    c.drawRect(x, y, x + ps, y + ps, pp)
                }
            }
        }
        if (radius <= 0f) return out
        val res = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val rc = Canvas(res)
        rc.drawRoundRect(RectF(0f, 0f, W.toFloat(), H.toFloat()), radius, radius, Paint(Paint.ANTI_ALIAS_FLAG))
        rc.drawBitmap(out, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN) })
        return res
    }
}
